<?php
// Accueil du site : l'écran pharmacie « Présentez votre badge » (ou l'espace de la personne connectée)
require __DIR__ . '/includes/init.php';
redirect(est_connecte() ? page_accueil() : 'borne.php');
