<?php
require __DIR__ . '/includes/init.php';
$_SESSION = [];
session_destroy();
redirect('borne.php');   // retour à « Présentez votre badge »
