<?php
// Filtres du journal, partagés par logs.php et le rafraîchissement automatique
if (!defined('APP')) exit;

function filtres_logs(array $g): array
{
    $du = preg_match('/^\d{4}-\d{2}-\d{2}$/', $g['du'] ?? '') ? $g['du'] : '';
    $au = preg_match('/^\d{4}-\d{2}-\d{2}$/', $g['au'] ?? '') ? $g['au'] : '';
    $res = in_array($g['resultat'] ?? '', ['autorise', 'refuse'], true) ? $g['resultat'] : '';
    $lect = (int)($g['lecteur'] ?? 0);
    $q = trim($g['q'] ?? '');

    $where = [];
    $params = [];
    if ($du !== '') { $where[] = 'l.date_heure >= ?'; $params[] = $du . ' 00:00:00'; }
    if ($au !== '') { $where[] = 'l.date_heure <= ?'; $params[] = $au . ' 23:59:59'; }
    if ($res !== '') { $where[] = 'l.resultat = ?'; $params[] = $res; }
    if ($lect > 0) { $where[] = 'l.lecteur_id = ?'; $params[] = $lect; }
    if ($q !== '') {
        $where[] = '(l.uid_badge LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ? OR l.motif LIKE ?)';
        array_push($params, "%$q%", "%$q%", "%$q%", "%$q%");
    }
    return [$where, $params, compact('du', 'au', 'res', 'lect', 'q')];
}
