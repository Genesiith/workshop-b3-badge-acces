<?php if (!defined('APP')) exit; ?>
  </main>
</div>
<script>
(function () {
  var h = document.getElementById('horloge');
  if (!h) return;
  function tick() {
    var d = new Date();
    h.textContent = d.toLocaleDateString('fr-FR') + '  ' + d.toLocaleTimeString('fr-FR');
  }
  tick(); setInterval(tick, 1000);
})();
</script>
</body>
</html>
