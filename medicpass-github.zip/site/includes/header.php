<?php
if (!defined('APP')) exit;
$page = $page ?? '';
$nav = [
    'index' => ['tableau.php', 'Tableau de bord', ['admin']],
    'stats' => ['statistiques.php', 'Statistiques', ['admin']],
    'patients' => ['patients.php', 'Patients', ['admin', 'medecin']],
    'ordonnances' => ['ordonnances.php', 'Ordonnances', ['admin', 'medecin']],
    'medicaments' => ['medicaments.php', 'Médicaments', ['admin']],
    'lecteurs' => ['lecteurs.php', 'Lecteurs', ['admin']],
    'borne' => ['borne.php', 'Pharmacie', ['admin', 'pharmacien']],
    'logs' => ['logs.php', 'Journal', ['admin']],
    'parametres' => ['parametres.php', 'Paramètres', ['admin']],
    'comptes' => ['comptes.php', role() === 'admin' ? 'Comptes' : 'Mon compte', ['admin', 'medecin', 'pharmacien']],
];
$i = 0;
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Medic Pass</title>
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="hud">
<div class="app">
  <aside class="sidebar">
    <a class="marque" href="<?= page_accueil() ?>"><span class="logo" aria-hidden="true"></span><span>MEDIC<b>PASS</b></span></a>
    <div class="sys"><span class="point"></span>Profil <?= e(ROLES[role()] ?? '') ?></div>
    <nav>
      <?php foreach ($nav as $key => [$href, $label, $roles]): if (!in_array(role(), $roles, true)) continue; $i++; ?>
        <a href="<?= $href ?>" class="<?= $page === $key ? 'actif' : '' ?>"><span class="nav-idx"><?= sprintf('%02d', $i) ?></span><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="session">
      <span class="muted">Opérateur</span><br><strong><?= e($_SESSION['admin_nom'] ?? '') ?></strong><br>
      <a href="logout.php">Verrouiller (retour pharmacie)</a>
    </div>
  </aside>
  <main class="contenu">
    <header class="topbar">
      <div>
        <div class="fil">MEDIC PASS // <?= e($title ?? '') ?></div>
        <h1><?= e($title ?? '') ?></h1>
      </div>
      <div class="horloge mono" id="horloge" aria-hidden="true"></div>
    </header>
    <?php foreach (flashes() as [$type, $msg]): ?>
      <div class="alerte alerte-<?= e($type) ?>"><?= e($msg) ?></div>
    <?php endforeach; ?>
