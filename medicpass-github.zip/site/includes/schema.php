<?php
if (!defined('APP')) exit;

// Tables créées par install.php (nouvelle installation)
// et par mise-a-jour.php (les tables marquées "nouvelle" uniquement)
return [
    'admins' => "CREATE TABLE IF NOT EXISTS admins (
        id INT AUTO_INCREMENT PRIMARY KEY,
        identifiant VARCHAR(50) NOT NULL UNIQUE,
        mot_de_passe VARCHAR(255) NOT NULL,
        role ENUM('admin','medecin','pharmacien') NOT NULL DEFAULT 'admin',
        uid_badge VARCHAR(32) NULL UNIQUE,
        cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'utilisateurs' => "CREATE TABLE IF NOT EXISTS utilisateurs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(100) NOT NULL,
        prenom VARCHAR(100) NOT NULL,
        uid_badge VARCHAR(32) NULL UNIQUE,
        actif TINYINT(1) NOT NULL DEFAULT 1,
        cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'medicaments' => "CREATE TABLE IF NOT EXISTS medicaments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(100) NOT NULL,
        description VARCHAR(255) NOT NULL DEFAULT '',
        stock INT NOT NULL DEFAULT 0,
        delai_minutes INT NOT NULL DEFAULT 0,
        actif TINYINT(1) NOT NULL DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'lecteurs' => "CREATE TABLE IF NOT EXISTS lecteurs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(100) NOT NULL,
        emplacement VARCHAR(150) NOT NULL DEFAULT '',
        type ENUM('acces','pharmacie') NOT NULL DEFAULT 'acces',
        cle_api VARCHAR(64) NOT NULL UNIQUE,
        actif TINYINT(1) NOT NULL DEFAULT 1,
        derniere_activite DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'droits_acces' => "CREATE TABLE IF NOT EXISTS droits_acces (
        utilisateur_id INT NOT NULL,
        lecteur_id INT NOT NULL,
        PRIMARY KEY (utilisateur_id, lecteur_id),
        FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
        FOREIGN KEY (lecteur_id) REFERENCES lecteurs(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'logs' => "CREATE TABLE IF NOT EXISTS logs (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        date_heure DATETIME NOT NULL,
        uid_badge VARCHAR(32) NOT NULL,
        utilisateur_id INT NULL,
        lecteur_id INT NULL,
        medicament_id INT NULL,
        resultat ENUM('autorise','refuse') NOT NULL,
        motif VARCHAR(255) NOT NULL DEFAULT '',
        INDEX idx_date (date_heure),
        INDEX idx_uid (uid_badge),
        FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE SET NULL,
        FOREIGN KEY (lecteur_id) REFERENCES lecteurs(id) ON DELETE SET NULL,
        FOREIGN KEY (medicament_id) REFERENCES medicaments(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    // ---- nouvelles tables (version 2) ----
    'ordonnances' => "CREATE TABLE IF NOT EXISTS ordonnances (
        id INT AUTO_INCREMENT PRIMARY KEY,
        patient_id INT NOT NULL,
        medecin_id INT NULL,
        cree_le DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        date_expiration DATE NOT NULL,
        statut ENUM('active','terminee','annulee') NOT NULL DEFAULT 'active',
        note VARCHAR(255) NOT NULL DEFAULT '',
        INDEX idx_patient (patient_id, statut),
        FOREIGN KEY (patient_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
        FOREIGN KEY (medecin_id) REFERENCES admins(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'ordonnance_lignes' => "CREATE TABLE IF NOT EXISTS ordonnance_lignes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ordonnance_id INT NOT NULL,
        medicament_id INT NOT NULL,
        quantite INT NOT NULL DEFAULT 1,
        delivre INT NOT NULL DEFAULT 0,
        posologie VARCHAR(255) NOT NULL DEFAULT '',
        FOREIGN KEY (ordonnance_id) REFERENCES ordonnances(id) ON DELETE CASCADE,
        FOREIGN KEY (medicament_id) REFERENCES medicaments(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'delivrances' => "CREATE TABLE IF NOT EXISTS delivrances (
        id INT AUTO_INCREMENT PRIMARY KEY,
        date_heure DATETIME NOT NULL,
        patient_id INT NULL,
        medicament_id INT NULL,
        ligne_id INT NULL,
        quantite INT NOT NULL,
        lecteur_id INT NULL,
        compte_id INT NULL,
        INDEX idx_date (date_heure),
        FOREIGN KEY (patient_id) REFERENCES utilisateurs(id) ON DELETE SET NULL,
        FOREIGN KEY (medicament_id) REFERENCES medicaments(id) ON DELETE SET NULL,
        FOREIGN KEY (ligne_id) REFERENCES ordonnance_lignes(id) ON DELETE SET NULL,
        FOREIGN KEY (lecteur_id) REFERENCES lecteurs(id) ON DELETE SET NULL,
        FOREIGN KEY (compte_id) REFERENCES admins(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'borne_sessions' => "CREATE TABLE IF NOT EXISTS borne_sessions (
        lecteur_id INT PRIMARY KEY,
        utilisateur_id INT NOT NULL,
        uid_badge VARCHAR(32) NOT NULL,
        expire DATETIME NOT NULL,
        FOREIGN KEY (lecteur_id) REFERENCES lecteurs(id) ON DELETE CASCADE,
        FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    // ---- nouvelles tables (version 3) ----
    'parametres' => "CREATE TABLE IF NOT EXISTS parametres (
        cle VARCHAR(64) PRIMARY KEY,
        valeur VARCHAR(255) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'conditions' => "CREATE TABLE IF NOT EXISTS conditions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nom VARCHAR(80) NOT NULL UNIQUE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'patient_conditions' => "CREATE TABLE IF NOT EXISTS patient_conditions (
        utilisateur_id INT NOT NULL,
        condition_id INT NOT NULL,
        PRIMARY KEY (utilisateur_id, condition_id),
        FOREIGN KEY (utilisateur_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
        FOREIGN KEY (condition_id) REFERENCES conditions(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    'medicament_contre_indications' => "CREATE TABLE IF NOT EXISTS medicament_contre_indications (
        medicament_id INT NOT NULL,
        condition_id INT NOT NULL,
        PRIMARY KEY (medicament_id, condition_id),
        FOREIGN KEY (medicament_id) REFERENCES medicaments(id) ON DELETE CASCADE,
        FOREIGN KEY (condition_id) REFERENCES conditions(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];
