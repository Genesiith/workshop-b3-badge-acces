<?php
// Gabarit des pages sans menu (connexion, installation, mise à jour)
if (!defined('APP')) exit;
function page_simple_debut(string $titre): void
{ ?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Medic Pass</title>
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="hud page-login">
  <div class="carte login panneau">
    <div class="marque marque-login"><span class="logo" aria-hidden="true"></span><span>MEDIC<b>PASS</b></span></div>
    <div class="fil"><?= e($titre) ?></div>
<?php }
function page_simple_fin(): void
{ ?>
  </div>
</body>
</html>
<?php }
