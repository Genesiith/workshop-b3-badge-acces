<?php
// =====================================================
//  CONFIGURATION DU SITE — à modifier avant d'installer
// =====================================================
if (!defined('APP')) exit;

// Base de données (infos données par Pterodactyl, onglet "Databases")
define('DB_HOST', '127.0.0.1');   // "Endpoint" sans le :port
define('DB_PORT', 3306);          // le port après les ":" de l'Endpoint
define('DB_NAME', 's1_rfid');     // "Database name"
define('DB_USER', 'u1_xxxxxxxx'); // "Username"
define('DB_PASS', 'mot_de_passe');// "Password"

// Réglages généraux
define('APP_NAME', 'RFID Health');
define('APP_TIMEZONE', 'Europe/Paris');
define('STOCK_ALERTE', 5); // alerte quand le stock d'un médicament passe sous ce nombre
