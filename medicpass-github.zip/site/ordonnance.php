<?php
require __DIR__ . '/includes/init.php';
require_role('admin', 'medecin');
$pdo = db();

$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT o.*, u.nom, u.prenom, u.uid_badge, a.identifiant AS medecin
    FROM ordonnances o JOIN utilisateurs u ON u.id = o.patient_id LEFT JOIN admins a ON a.id = o.medecin_id WHERE o.id = ?');
$st->execute([$id]);
$o = $st->fetch();
if (!$o) {
    flash('erreur', 'Ordonnance introuvable.');
    redirect('ordonnances.php');
}
$st = $pdo->prepare('SELECT l.*, m.nom, m.description FROM ordonnance_lignes l JOIN medicaments m ON m.id = l.medicament_id WHERE l.ordonnance_id = ? ORDER BY l.id');
$st->execute([$id]);
$lignes = $st->fetchAll();
$conditions = conditions_patient($pdo, (int)$o['patient_id']);
$st = $pdo->prepare('SELECT d.date_heure, d.quantite, m.nom, le.nom AS lecteur FROM delivrances d
    JOIN ordonnance_lignes l ON l.id = d.ligne_id
    LEFT JOIN medicaments m ON m.id = d.medicament_id
    LEFT JOIN lecteurs le ON le.id = d.lecteur_id
    WHERE l.ordonnance_id = ? ORDER BY d.id DESC');
$st->execute([$id]);
$delivrances = $st->fetchAll();

$title = 'Ordonnance #' . $id;
$page = 'ordonnances';
require __DIR__ . '/includes/header.php';
?>
<p class="no-print"><a href="ordonnances.php">Retour aux ordonnances</a> · <a href="#" onclick="window.print(); return false;">Imprimer</a></p>
<section class="panneau">
  <div class="panneau-tete"><h2>Prescription</h2><?= tag_ordonnance($o) ?></div>
  <dl class="fiche">
    <div><dt>Patient</dt><dd><?= role() === 'admin' ? '<a href="patient.php?id=' . (int)$o['patient_id'] . '">' . e($o['prenom'] . ' ' . $o['nom']) . '</a>' : e($o['prenom'] . ' ' . $o['nom']) ?></dd></div>
    <div><dt>Prescripteur</dt><dd><?= e($o['medecin'] ?? '—') ?></dd></div>
    <div><dt>Prescrite le</dt><dd class="mono"><?= e(date_fr($o['cree_le'], true, false)) ?></dd></div>
    <div><dt>Valable jusqu'au</dt><dd class="mono"><?= e(date_fr($o['date_expiration'], false)) ?></dd></div>
    <div><dt>Conditions du patient</dt><dd><?= $conditions ? e(implode(', ', array_column($conditions, 'nom'))) : '—' ?></dd></div>
  </dl>
  <?php if ($o['note'] !== ''): ?><p class="note">Note : <?= e($o['note']) ?></p><?php endif; ?>

  <div class="table-wrap"><table>
    <thead><tr><th>Médicament</th><th>Posologie</th><th class="num">Prescrit</th><th class="num">Délivré</th><th>Progression</th></tr></thead>
    <tbody>
    <?php foreach ($lignes as $l): $pct = $l['quantite'] ? min(100, round($l['delivre'] * 100 / $l['quantite'])) : 0; ?>
      <tr>
        <td><?= e($l['nom']) ?><?= $l['description'] ? '<br><span class="muted">' . e($l['description']) . '</span>' : '' ?></td>
        <td><?= e($l['posologie']) ?></td>
        <td class="num mono"><?= (int)$l['quantite'] ?></td>
        <td class="num mono"><?= (int)$l['delivre'] ?></td>
        <td><div class="jauge" role="img" aria-label="<?= $pct ?> % délivré"><span style="width: <?= $pct ?>%"></span></div></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2>Délivrances en pharmacie</h2></div>
  <?php if (!$delivrances): ?>
    <p class="vide">Rien n'a encore été retiré en pharmacie.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Date</th><th>Médicament</th><th class="num">Quantité</th><th>Borne</th></tr></thead>
      <tbody>
      <?php foreach ($delivrances as $d): ?>
        <tr><td class="mono"><?= e(date_fr($d['date_heure'])) ?></td><td><?= e($d['nom'] ?? '—') ?></td><td class="num mono"><?= (int)$d['quantite'] ?></td><td><?= e($d['lecteur'] ?? '—') ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
