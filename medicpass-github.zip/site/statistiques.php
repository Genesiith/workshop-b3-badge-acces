<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
check_csrf();
$pdo = db();

// Remise à zéro des statistiques
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reinitialiser') {
    $viderLogs = isset($_POST['logs']);
    $viderDeliv = isset($_POST['delivrances']);
    if (!$viderLogs && !$viderDeliv) {
        flash('erreur', 'Cochez au moins une donnée à effacer.');
    } else {
        $parts = [];
        if ($viderLogs) $parts[] = $pdo->exec('DELETE FROM logs') . ' passage(s) de badge';
        if ($viderDeliv) $parts[] = $pdo->exec('DELETE FROM delivrances') . ' délivrance(s)';
        flash('succes', 'Statistiques remises à zéro : ' . implode(' et ', $parts) . ' effacé(s).');
    }
    redirect('statistiques.php');
}

$jours = (int)($_GET['p'] ?? 30);
if (!in_array($jours, [7, 30, 90], true)) $jours = 30;
$debut = date('Y-m-d', strtotime('-' . ($jours - 1) . ' days'));

// Passages par jour (autorisés / refusés), jours vides compris
$parJour = [];
for ($d = 0; $d < $jours; $d++) {
    $parJour[date('Y-m-d', strtotime("$debut +$d days"))] = ['ok' => 0, 'ko' => 0];
}
$st = $pdo->prepare("SELECT DATE(date_heure) AS j, SUM(resultat = 'autorise') AS ok, SUM(resultat = 'refuse') AS ko
    FROM logs WHERE date_heure >= ? GROUP BY j");
$st->execute([$debut]);
foreach ($st->fetchAll() as $r) {
    if (isset($parJour[$r['j']])) $parJour[$r['j']] = ['ok' => (int)$r['ok'], 'ko' => (int)$r['ko']];
}
$totalOk = array_sum(array_column($parJour, 'ok'));
$totalKo = array_sum(array_column($parJour, 'ko'));
$total = $totalOk + $totalKo;

$st = $pdo->prepare('SELECT COALESCE(SUM(quantite), 0) FROM delivrances WHERE date_heure >= ?');
$st->execute([$debut]);
$delivres = (int)$st->fetchColumn();
$st = $pdo->prepare('SELECT COUNT(*) FROM ordonnances WHERE cree_le >= ?');
$st->execute([$debut]);
$nouvellesOrdos = (int)$st->fetchColumn();

// Médicaments les plus délivrés
$st = $pdo->prepare('SELECT m.nom, SUM(d.quantite) AS q FROM delivrances d JOIN medicaments m ON m.id = d.medicament_id
    WHERE d.date_heure >= ? GROUP BY m.id, m.nom ORDER BY q DESC LIMIT 8');
$st->execute([$debut]);
$topMeds = $st->fetchAll();

// Motifs de refus
$st = $pdo->prepare("SELECT motif, COUNT(*) AS n FROM logs WHERE resultat = 'refuse' AND date_heure >= ?
    GROUP BY motif ORDER BY n DESC LIMIT 6");
$st->execute([$debut]);
$refus = $st->fetchAll();

// Activité par heure
$parHeure = array_fill(0, 24, 0);
$st = $pdo->prepare('SELECT HOUR(date_heure) AS h, COUNT(*) AS n FROM logs WHERE date_heure >= ? GROUP BY h');
$st->execute([$debut]);
foreach ($st->fetchAll() as $r) $parHeure[(int)$r['h']] = (int)$r['n'];

// Ordonnances par prescripteur
$st = $pdo->prepare("SELECT COALESCE(a.identifiant, 'Compte supprimé') AS medecin, COUNT(*) AS n,
        SUM(o.statut = 'terminee') AS terminees
    FROM ordonnances o LEFT JOIN admins a ON a.id = o.medecin_id
    WHERE o.cree_le >= ? GROUP BY medecin ORDER BY n DESC");
$st->execute([$debut]);
$parMedecin = $st->fetchAll();

$donnees = [
    'jours' => array_map(fn($j) => date('d/m', strtotime($j)), array_keys($parJour)),
    'ok' => array_column($parJour, 'ok'),
    'ko' => array_column($parJour, 'ko'),
    'meds' => array_column($topMeds, 'nom'),
    'medsQ' => array_map('intval', array_column($topMeds, 'q')),
    'refus' => array_column($refus, 'motif'),
    'refusN' => array_map('intval', array_column($refus, 'n')),
    'heures' => array_map(fn($h) => sprintf('%02dh', $h), range(0, 23)),
    'heuresN' => $parHeure,
];

$title = 'Statistiques';
$page = 'stats';
require __DIR__ . '/includes/header.php';
?>
<nav class="onglets">
  <?php foreach ([7 => '7 jours', 30 => '30 jours', 90 => '90 jours'] as $p => $lib): ?>
    <a href="?p=<?= $p ?>" class="<?= $jours === $p ? 'actif' : '' ?>"><?= $lib ?></a>
  <?php endforeach; ?>
</nav>

<div class="stats">
  <div class="stat"><span class="stat-label">Passages de badge</span><span class="stat-val"><?= $total ?></span></div>
  <div class="stat"><span class="stat-label">Taux de refus</span><span class="stat-val"><?= $total ? round($totalKo * 100 / $total) : 0 ?><small>%</small></span></div>
  <div class="stat"><span class="stat-label">Produits délivrés</span><span class="stat-val"><?= $delivres ?></span></div>
  <div class="stat"><span class="stat-label">Ordonnances créées</span><span class="stat-val"><?= $nouvellesOrdos ?></span></div>
</div>

<section class="panneau">
  <div class="panneau-tete"><h2>Passages par jour</h2><span class="muted">Autorisés et refusés</span></div>
  <div class="graphe graphe-large"><canvas id="g-jours"></canvas></div>
</section>

<div class="grille">
  <section class="panneau">
    <div class="panneau-tete"><h2>Médicaments les plus délivrés</h2><span class="muted">Unités</span></div>
    <?php if (!$topMeds): ?><p class="vide">Aucune délivrance sur la période.</p>
    <?php else: ?><div class="graphe"><canvas id="g-meds"></canvas></div><?php endif; ?>
  </section>
  <section class="panneau">
    <div class="panneau-tete"><h2>Motifs de refus</h2><span class="muted">Nombre de passages</span></div>
    <?php if (!$refus): ?><p class="vide">Aucun refus sur la période.</p>
    <?php else: ?><div class="graphe"><canvas id="g-refus"></canvas></div><?php endif; ?>
  </section>
</div>

<div class="grille">
  <section class="panneau">
    <div class="panneau-tete"><h2>Activité par heure</h2><span class="muted">Passages cumulés sur la période</span></div>
    <div class="graphe"><canvas id="g-heures"></canvas></div>
  </section>
  <section class="panneau">
    <div class="panneau-tete"><h2>Ordonnances par prescripteur</h2></div>
    <?php if (!$parMedecin): ?><p class="vide">Aucune ordonnance sur la période.</p>
    <?php else: ?>
      <div class="table-wrap"><table>
        <thead><tr><th>Prescripteur</th><th class="num">Ordonnances</th><th class="num">Entièrement délivrées</th></tr></thead>
        <tbody>
        <?php foreach ($parMedecin as $r): ?>
          <tr><td><?= e($r['medecin']) ?></td><td class="num mono"><?= (int)$r['n'] ?></td><td class="num mono"><?= (int)$r['terminees'] ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php endif; ?>
  </section>
</div>

<section class="panneau panneau-danger">
  <div class="panneau-tete"><h2>Remise à zéro</h2><span class="muted">Action définitive</span></div>
  <p class="muted">Efface l'historique pour repartir de zéro. Les patients, ordonnances, médicaments, stocks et lecteurs ne sont pas touchés.</p>
  <form method="post" class="formulaire"<?= confirm_attr('Effacer définitivement les données cochées ? Cette action est irréversible.') ?>>
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="reinitialiser">
    <label class="case"><input type="checkbox" name="logs" checked> Tous les passages de badge (journal, refus, badges inconnus)</label>
    <label class="case"><input type="checkbox" name="delivrances" checked> L'historique des délivrances en pharmacie</label>
    <button class="btn btn-danger">Remettre les statistiques à zéro</button>
  </form>
</section>

<script src="assets/chart.umd.min.js"></script>
<script>
(function () {
  if (!window.Chart) return;
  var D = <?= json_encode($donnees, JSON_UNESCAPED_UNICODE) ?>;
  var cyan = '#3fd0ff', rouge = '#ff5566', ambre = '#ffb347';
  Chart.defaults.color = '#8ea9bd';
  Chart.defaults.font.family = "'Share Tech Mono', monospace";
  Chart.defaults.borderColor = 'rgba(63, 208, 255, 0.08)';
  Chart.defaults.plugins.legend.labels.boxWidth = 12;
  var axes = { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 } } };

  new Chart(document.getElementById('g-jours'), {
    type: 'bar',
    data: { labels: D.jours, datasets: [
      { label: 'Autorisés', data: D.ok, backgroundColor: cyan, stack: 's' },
      { label: 'Refusés', data: D.ko, backgroundColor: rouge, stack: 's' }
    ] },
    options: { maintainAspectRatio: false, scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, beginAtZero: true, ticks: { precision: 0 } } } }
  });
  if (document.getElementById('g-meds')) new Chart(document.getElementById('g-meds'), {
    type: 'bar',
    data: { labels: D.meds, datasets: [{ label: 'Unités délivrées', data: D.medsQ, backgroundColor: cyan }] },
    options: { indexAxis: 'y', maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } }, y: { grid: { display: false } } } }
  });
  if (document.getElementById('g-refus')) new Chart(document.getElementById('g-refus'), {
    type: 'bar',
    data: { labels: D.refus, datasets: [{ label: 'Refus', data: D.refusN, backgroundColor: rouge }] },
    options: { indexAxis: 'y', maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, ticks: { precision: 0 } }, y: { grid: { display: false } } } }
  });
  new Chart(document.getElementById('g-heures'), {
    type: 'bar',
    data: { labels: D.heures, datasets: [{ label: 'Passages', data: D.heuresN, backgroundColor: ambre }] },
    options: { maintainAspectRatio: false, plugins: { legend: { display: false } }, scales: axes }
  });
})();
</script>
<?php require __DIR__ . '/includes/footer.php';
