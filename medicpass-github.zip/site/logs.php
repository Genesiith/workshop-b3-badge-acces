<?php
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/filtres_logs.php';
require_role('admin');
$pdo = db();

[$where, $params, $f] = filtres_logs($_GET);
extract($f);   // $du, $au, $res, $lect, $q
$sqlWhere = $where ? ' WHERE ' . implode(' AND ', $where) : '';

// Export CSV (ouvrable dans Excel)
if (($_GET['export'] ?? '') === 'csv') {
    $st = $pdo->prepare(LOGS_SELECT . $sqlWhere . ' ORDER BY l.id DESC LIMIT 50000');
    $st->execute($params);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="journal-lectures-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Date', 'Badge', 'Patient', 'Lecteur', 'Médicament', 'Résultat', 'Motif'], ';', '"', '');
    while ($r = $st->fetch()) {
        fputcsv($out, [
            date_fr($r['date_heure']),
            $r['uid_badge'],
            $r['utilisateur_id'] ? $r['u_prenom'] . ' ' . $r['u_nom'] : 'Inconnu',
            $r['lecteur_nom'] ?? '',
            $r['med_nom'] ?? '',
            $r['resultat'] === 'autorise' ? 'Autorisé' : 'Refusé',
            $r['motif'],
        ], ';', '"', '');
    }
    exit;
}

$parPage = 50;
$st = $pdo->prepare('SELECT COUNT(*) FROM logs l LEFT JOIN utilisateurs u ON u.id = l.utilisateur_id' . $sqlWhere);
$st->execute($params);
$total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / $parPage));
$pageNum = min($pages, max(1, (int)($_GET['page'] ?? 1)));
$st = $pdo->prepare(LOGS_SELECT . $sqlWhere . ' ORDER BY l.id DESC LIMIT ' . $parPage . ' OFFSET ' . (($pageNum - 1) * $parPage));
$st->execute($params);
$rows = $st->fetchAll();
$lecteurs = $pdo->query('SELECT id, nom FROM lecteurs ORDER BY nom')->fetchAll();

function lien_page(int $n): string
{
    return 'logs.php?' . http_build_query(array_merge($_GET, ['page' => $n]));
}

$title = 'Journal';
$page = 'logs';
require __DIR__ . '/includes/header.php';
?>
<section class="panneau">
  <form method="get" class="filtres">
    <label>Du<input type="date" name="du" value="<?= e($du) ?>"></label>
    <label>Au<input type="date" name="au" value="<?= e($au) ?>"></label>
    <label>Résultat
      <select name="resultat">
        <option value="">Tous</option>
        <option value="autorise" <?= $res === 'autorise' ? 'selected' : '' ?>>Autorisés</option>
        <option value="refuse" <?= $res === 'refuse' ? 'selected' : '' ?>>Refusés</option>
      </select>
    </label>
    <label>Lecteur
      <select name="lecteur">
        <option value="0">Tous</option>
        <?php foreach ($lecteurs as $l): ?>
          <option value="<?= (int)$l['id'] ?>" <?= $lect === (int)$l['id'] ? 'selected' : '' ?>><?= e($l['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Recherche<input name="q" value="<?= e($q) ?>" placeholder="Nom, badge, motif"></label>
    <div class="actions">
      <button class="btn btn-primaire">Filtrer</button>
      <a class="btn" href="logs.php">Réinitialiser</a>
      <a class="btn" href="<?= e('logs.php?' . http_build_query(array_merge($_GET, ['export' => 'csv']))) ?>">Exporter en CSV</a>
    </div>
  </form>
</section>

<section class="panneau">
  <div class="panneau-tete">
    <h2><span id="journal-total"><?= $total ?></span> lecture<?= $total > 1 ? 's' : '' ?></h2>
    <span class="muted"><?php if ($pageNum === 1): ?><span class="point-live"></span>Mise à jour automatique · <?php endif; ?>Page <?= $pageNum ?> sur <?= $pages ?></span>
  </div>
  <?= logs_table($rows, $where ? 'Aucune lecture ne correspond à ces filtres.' : 'Aucune lecture enregistrée. Passez un badge sur un lecteur pour voir la première ligne apparaître ici.', 'journal-corps') ?>
  <?php if ($pages > 1): ?>
    <nav class="pagination">
      <?php if ($pageNum > 1): ?><a class="btn btn-sm" href="<?= e(lien_page($pageNum - 1)) ?>">Page précédente</a><?php endif; ?>
      <?php if ($pageNum < $pages): ?><a class="btn btn-sm" href="<?= e(lien_page($pageNum + 1)) ?>">Page suivante</a><?php endif; ?>
    </nav>
  <?php endif; ?>
</section>
<?php if ($pageNum === 1): ?>
<script>
// Rafraîchissement automatique du journal : les nouvelles lectures arrivent toutes les 4 secondes
(function () {
  var corps = document.getElementById('journal-corps'), total = document.getElementById('journal-total');
  if (!corps) return;
  var params = new URLSearchParams(window.location.search);
  params.delete('page');
  var premiere = corps.querySelector('tr[data-id]');
  var dernierId = premiere ? Number(premiere.dataset.id) : 0;

  function tick() {
    if (document.hidden) return;
    params.set('after', dernierId);
    fetch('logs_flux.php?' + params.toString(), { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        if (!d || !d.lignes) return;
        if (total && typeof d.total === 'number') total.textContent = d.total;
        if (!d.lignes.length) return;
        var vide = document.querySelector('.vide-journal[data-pour="journal-corps"]');
        if (vide) { vide.remove(); corps.closest('table').hidden = false; }
        d.lignes.forEach(function (l) {
          var tmp = document.createElement('tbody');
          tmp.innerHTML = l.html;
          var tr = tmp.firstElementChild;
          if (!tr) return;
          tr.classList.add('ligne-nouvelle');
          corps.insertBefore(tr, corps.firstChild);
          if (l.id > dernierId) dernierId = l.id;
        });
        while (corps.rows.length > 50) corps.deleteRow(corps.rows.length - 1);
      })
      .catch(function () {});
  }
  setInterval(tick, 4000);
  document.addEventListener('visibilitychange', function () { if (!document.hidden) tick(); });
})();
</script>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php';
