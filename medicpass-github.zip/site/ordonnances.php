<?php
require __DIR__ . '/includes/init.php';
require_role('admin', 'medecin');
check_csrf();
$pdo = db();
$moi = (int)$_SESSION['admin_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'creer') {
            $patientId = (int)($_POST['patient_id'] ?? 0);
            $exp = (string)($_POST['date_expiration'] ?? '');
            $note = trim($_POST['note'] ?? '');
            $meds = (array)($_POST['med'] ?? []);
            $qtes = (array)($_POST['qte'] ?? []);
            $posos = (array)($_POST['poso'] ?? []);
            $lignes = [];
            foreach ($meds as $i => $m) {
                $m = (int)$m;
                $q = (int)($qtes[$i] ?? 0);
                if ($m > 0 && $q > 0) $lignes[] = [$m, min($q, 999), trim((string)($posos[$i] ?? ''))];
            }
            $st = $pdo->prepare('SELECT COUNT(*) FROM utilisateurs WHERE id = ?');
            $st->execute([$patientId]);
            if (!(int)$st->fetchColumn()) {
                flash('erreur', 'Choisissez un patient.');
            } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $exp) || $exp < date('Y-m-d')) {
                flash('erreur', "La date de fin de validité doit être aujourd'hui ou plus tard.");
            } elseif (!$lignes) {
                flash('erreur', 'Ajoutez au moins un médicament avec une quantité.');
            } elseif ($conflits = array_filter(array_map(function ($l) use ($pdo, $patientId) {
                $ci = contre_indications($pdo, $patientId, $l[0]);
                if (!$ci) return null;
                $st = $pdo->prepare('SELECT nom FROM medicaments WHERE id = ?');
                $st->execute([$l[0]]);
                return $st->fetchColumn() . ' (' . implode(', ', $ci) . ')';
            }, $lignes))) {
                flash('erreur', 'Ordonnance refusée : contre-indication pour ce patient : ' . implode(' ; ', $conflits) . '.');
                redirect('ordonnances.php?patient=' . $patientId . '#nouvelle');
            } else {
                $pdo->beginTransaction();
                $pdo->prepare('INSERT INTO ordonnances (patient_id, medecin_id, date_expiration, note) VALUES (?, ?, ?, ?)')
                    ->execute([$patientId, $moi, $exp, couper($note, 255)]);
                $oid = (int)$pdo->lastInsertId();
                $ins = $pdo->prepare('INSERT INTO ordonnance_lignes (ordonnance_id, medicament_id, quantite, posologie) VALUES (?, ?, ?, ?)');
                foreach ($lignes as [$m, $q, $p]) $ins->execute([$oid, $m, $q, couper($p, 255)]);
                $pdo->commit();
                flash('succes', "Ordonnance #$oid enregistrée. Le patient peut passer son badge en pharmacie.");
                redirect('ordonnance.php?id=' . $oid);
            }
        } elseif ($action === 'annuler') {
            $id = (int)($_POST['id'] ?? 0);
            $sql = "UPDATE ordonnances SET statut = 'annulee' WHERE id = ? AND statut = 'active'";
            $params = [$id];
            if (role() !== 'admin') { $sql .= ' AND medecin_id = ?'; $params[] = $moi; }
            $st = $pdo->prepare($sql);
            $st->execute($params);
            flash($st->rowCount() ? 'succes' : 'erreur', $st->rowCount() ? "Ordonnance #$id annulée." : "Impossible d'annuler cette ordonnance (déjà close, ou prescrite par un autre médecin).");
        }
    } catch (PDOException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('erreur', 'Erreur de base de données : ' . $ex->getMessage());
    }
    redirect('ordonnances.php');
}

$patients = $pdo->query("SELECT u.id, u.nom, u.prenom, u.uid_badge,
        (SELECT GROUP_CONCAT(c.nom ORDER BY c.nom SEPARATOR ', ') FROM patient_conditions pc JOIN conditions c ON c.id = pc.condition_id WHERE pc.utilisateur_id = u.id) AS conditions
    FROM utilisateurs u WHERE u.actif = 1 ORDER BY u.nom, u.prenom")->fetchAll();
$meds = $pdo->query('SELECT id, nom, description, stock FROM medicaments WHERE actif = 1 ORDER BY nom')->fetchAll();
$patientChoisi = (int)($_GET['patient'] ?? 0);

$filtre = in_array($_GET['statut'] ?? '', ['active', 'terminee', 'annulee', 'expiree'], true) ? $_GET['statut'] : '';
$q = trim($_GET['q'] ?? '');
$where = [];
$params = [];
if ($filtre === 'active') $where[] = "o.statut = 'active' AND o.date_expiration >= CURDATE()";
if ($filtre === 'expiree') $where[] = "o.statut = 'active' AND o.date_expiration < CURDATE()";
if ($filtre === 'terminee' || $filtre === 'annulee') { $where[] = 'o.statut = ?'; $params[] = $filtre; }
if ($q !== '') { $where[] = '(u.nom LIKE ? OR u.prenom LIKE ?)'; array_push($params, "%$q%", "%$q%"); }
$st = $pdo->prepare("SELECT o.*, u.nom, u.prenom, a.identifiant AS medecin,
        (SELECT GROUP_CONCAT(CONCAT(m.nom, ' ', l.delivre, '/', l.quantite) SEPARATOR ' · ')
           FROM ordonnance_lignes l JOIN medicaments m ON m.id = l.medicament_id WHERE l.ordonnance_id = o.id) AS resume
    FROM ordonnances o JOIN utilisateurs u ON u.id = o.patient_id LEFT JOIN admins a ON a.id = o.medecin_id"
    . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY o.id DESC LIMIT 200');
$st->execute($params);
$ordos = $st->fetchAll();

$title = 'Ordonnances';
$page = 'ordonnances';
require __DIR__ . '/includes/header.php';
?>
<section class="panneau" id="nouvelle">
  <div class="panneau-tete"><h2>Nouvelle ordonnance</h2><span class="muted">Prescripteur : <?= e($_SESSION['admin_nom']) ?></span></div>
  <?php if (!$patients || !$meds): ?>
    <p class="vide">Il faut au moins un patient et un médicament actifs pour prescrire<?= role() === 'admin' ? ' : voir Patients et Médicaments' : " : demandez à l'administrateur de les créer" ?>.</p>
  <?php else: ?>
  <form method="post" class="formulaire formulaire-large">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="creer">
    <div class="ligne2">
      <label>Patient
        <select name="patient_id" required>
          <option value="">Choisir un patient…</option>
          <?php foreach ($patients as $p): ?>
            <option value="<?= (int)$p['id'] ?>" <?= $patientChoisi === (int)$p['id'] ? 'selected' : '' ?>><?= e($p['nom'] . ' ' . $p['prenom']) ?><?= $p['conditions'] ? ' — ' . e($p['conditions']) : '' ?><?= $p['uid_badge'] ? '' : ' (sans badge)' ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Valable jusqu'au<input type="date" name="date_expiration" min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d', strtotime('+3 months')) ?>" required></label>
    </div>

    <div class="table-wrap">
      <table class="lignes-ordo">
        <thead><tr><th>Médicament</th><th class="col-qte">Quantité</th><th>Posologie</th><th></th></tr></thead>
        <tbody id="lignes">
          <tr>
            <td><select name="med[]" required><option value="">Choisir…</option>
              <?php foreach ($meds as $m): ?><option value="<?= (int)$m['id'] ?>"><?= e($m['nom']) ?><?= $m['description'] ? ' – ' . e($m['description']) : '' ?></option><?php endforeach; ?>
            </select></td>
            <td><input type="number" name="qte[]" value="1" min="1" max="999" required></td>
            <td><input name="poso[]" placeholder="1 comprimé matin et soir pendant 5 jours"></td>
            <td><button type="button" class="btn btn-sm btn-danger" onclick="retirerLigne(this)" aria-label="Retirer la ligne">Retirer</button></td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="actions"><button type="button" class="btn btn-sm" onclick="ajouterLigne()">+ Ajouter un médicament</button></div>

    <p class="muted">Les médicaments contre-indiqués pour les conditions du patient (affichées à côté de son nom) sont refusés à l'enregistrement.</p>
    <label>Note (facultatif)<input name="note" maxlength="255" placeholder="Remarque pour le pharmacien"></label>
    <button class="btn btn-primaire">Signer et enregistrer l'ordonnance</button>
  </form>
  <script>
  function ajouterLigne() {
    var tb = document.getElementById('lignes');
    var copie = tb.rows[0].cloneNode(true);
    copie.querySelector('select').value = '';
    copie.querySelector('input[name="qte[]"]').value = 1;
    copie.querySelector('input[name="poso[]"]').value = '';
    tb.appendChild(copie);
  }
  function retirerLigne(btn) {
    var tb = document.getElementById('lignes');
    if (tb.rows.length > 1) btn.closest('tr').remove();
  }
  </script>
  <?php endif; ?>
</section>

<section class="panneau">
  <div class="panneau-tete">
    <h2>Registre des ordonnances</h2>
    <form method="get" class="recherche">
      <select name="statut">
        <option value="">Tous les statuts</option>
        <?php foreach (['active' => 'Actives', 'expiree' => 'Expirées', 'terminee' => 'Délivrées', 'annulee' => 'Annulées'] as $v => $lib): ?>
          <option value="<?= $v ?>" <?= $filtre === $v ? 'selected' : '' ?>><?= $lib ?></option>
        <?php endforeach; ?>
      </select>
      <input name="q" value="<?= e($q) ?>" placeholder="Nom du patient">
      <button class="btn btn-sm">Filtrer</button>
    </form>
  </div>
  <?php if (!$ordos): ?>
    <p class="vide">Aucune ordonnance<?= ($filtre || $q) ? ' ne correspond à ces filtres' : ' pour le moment' ?>.</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>N°</th><th>Patient</th><th>Prescrite le</th><th>Par</th><th>Produits (délivrés / prescrits)</th><th>Valable jusqu'au</th><th>Statut</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($ordos as $o): ?>
      <tr>
        <td><a href="ordonnance.php?id=<?= (int)$o['id'] ?>" class="mono">#<?= (int)$o['id'] ?></a></td>
        <td><?= e($o['prenom'] . ' ' . $o['nom']) ?></td>
        <td class="mono"><?= e(date_fr($o['cree_le'], false)) ?></td>
        <td><?= e($o['medecin'] ?? '—') ?></td>
        <td><?= e($o['resume']) ?></td>
        <td class="mono"><?= e(date_fr($o['date_expiration'], false)) ?></td>
        <td><?= tag_ordonnance($o) ?></td>
        <td class="actions">
          <a class="btn btn-sm" href="ordonnance.php?id=<?= (int)$o['id'] ?>">Voir</a>
          <?php if ($o['statut'] === 'active' && (role() === 'admin' || (int)$o['medecin_id'] === $moi)): ?>
            <?= action_btn('annuler', (int)$o['id'], 'Annuler', 'btn-danger', 'Annuler l\'ordonnance #' . $o['id'] . ' ? Le patient ne pourra plus retirer les produits restants.') ?>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
