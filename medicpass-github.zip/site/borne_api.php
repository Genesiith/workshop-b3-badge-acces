<?php
// Données de l'écran pharmacie (appelé en boucle par borne.php)
ini_set('display_errors', '0');   // un avertissement PHP ne doit jamais casser la réponse JSON
ob_start();
require __DIR__ . '/includes/init.php';
header('Content-Type: application/json; charset=utf-8');

function json_sortie(array $data, int $code = 200): void
{
    while (ob_get_level()) ob_end_clean();
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) {
    json_sortie(['erreur' => 'Jeton de sécurité invalide : rechargez la page.'], 400);
}

$action = $_GET['action'] ?? $_POST['action'] ?? 'etat';
$lecteurId = (int)($_GET['lecteur'] ?? $_POST['lecteur'] ?? 0);

try {
    $pdo = db();
    // Accès : pharmacien/admin connecté, ou écran pharmacie public (uniquement pour le lecteur de la borne)
    $kiosque = !est_connecte() && $lecteurId === borne_lecteur($pdo);
    if (!$kiosque && (!est_connecte() || !in_array(role(), ['admin', 'pharmacien'], true))) {
        json_sortie(['erreur' => 'Session expirée : reconnectez-vous.'], 401);
    }
    $st = $pdo->prepare("SELECT * FROM lecteurs WHERE id = ?");
    $st->execute([$lecteurId]);
    $lecteur = $st->fetch();
    if (!$lecteur) json_sortie(['erreur' => 'Borne pharmacie introuvable.'], 404);

    $pdo->exec('DELETE FROM borne_sessions WHERE expire < NOW()');
    $st = $pdo->prepare('SELECT s.*, TIMESTAMPDIFF(SECOND, NOW(), s.expire) AS reste, u.nom, u.prenom, u.actif
        FROM borne_sessions s JOIN utilisateurs u ON u.id = s.utilisateur_id WHERE s.lecteur_id = ?');
    $st->execute([$lecteurId]);
    $session = $st->fetch();

    // ---- Annuler : le patient quitte l'écran ----
    if ($action === 'annuler') {
        $pdo->prepare('DELETE FROM borne_sessions WHERE lecteur_id = ?')->execute([$lecteurId]);
        json_sortie(['ok' => true]);
    }

    // ---- État : qui est devant l'écran et quels sont ses droits ----
    if ($action === 'etat') {
        // Badge administrateur passé il y a moins de 30 s : la borne installée ouvre l'administration
        if ($kiosque && !est_connecte()) {
            [$jeton, $quand, $compteId] = array_pad(explode('|', (string)param_get($pdo, 'deverrou_' . $lecteurId, '')), 3, '');
            if ($jeton !== '' && time() - (int)$quand <= 30) {
                $st = $pdo->prepare('SELECT identifiant, role FROM admins WHERE id = ?');
                $st->execute([(int)$compteId]);
                $c = $st->fetch() ?: ['identifiant' => '', 'role' => 'admin'];
                json_sortie(['etat' => 'admin', 'jeton' => $jeton, 'profil' => ROLES[$c['role']] ?? '', 'compte' => $c['identifiant']]);
            }
        }
        $ae = alerte_etat($pdo, $lecteurId);
        if ($ae['active'] && $ae['verrou']) json_sortie(['etat' => 'alerte']);
        if (!$session) {
            // Badge refusé il y a moins de 8 secondes sur ce lecteur -> message au patient
            $st = $pdo->prepare("SELECT l.motif, l.utilisateur_id, u.prenom FROM logs l LEFT JOIN utilisateurs u ON u.id = l.utilisateur_id
                WHERE l.lecteur_id = ? AND l.resultat = 'refuse' AND l.date_heure >= NOW() - INTERVAL 8 SECOND
                ORDER BY l.id DESC LIMIT 1");
            $st->execute([$lecteurId]);
            $refus = $st->fetch();
            if ($refus) {
                $messages = [
                    'Aucune ordonnance en cours' => ['Aucun médicament à retirer', "Vous n'avez pas d'ordonnance en cours. Consultez votre médecin."],
                    'Badge inconnu' => ['Badge non reconnu', "Ce badge n'est associé à aucun patient. Adressez-vous au comptoir."],
                    'Patient désactivé' => ['Accès refusé', 'Votre dossier est désactivé. Adressez-vous au comptoir.'],
                    'Lecteur désactivé' => ['Borne hors service', 'Adressez-vous au comptoir.'],
                ];
                if (str_starts_with($refus['motif'], 'Délai non écoulé') && $refus['utilisateur_id']) {
                    // Temps d'attente recalculé à la seconde près pour chaque médicament concerné
                    $phrases = [];
                    foreach (lignes_disponibles($pdo, (int)$refus['utilisateur_id']) as $l) {
                        $et = etat_ligne($l);
                        if ($et['prochaine']) $phrases[$l['nom']] = texte_attente($et['prochaine'], $l['nom']) . '.';
                    }
                    [$titre, $detail] = ['Vous devez encore patienter', $phrases ? implode(' ', $phrases) : 'Le délai entre deux prises n\'est pas écoulé.'];
                } elseif (str_starts_with($refus['motif'], 'Aucun médicament disponible')) {
                    [$titre, $detail] = ['Rien à retirer pour le moment', 'Vos médicaments sont indisponibles (rupture ou contre-indication). Adressez-vous au comptoir.'];
                } else {
                    [$titre, $detail] = $messages[$refus['motif']] ?? ['Accès refusé', $refus['motif'] . '. Adressez-vous au comptoir.'];
                }
                json_sortie(['etat' => 'refus', 'titre' => $titre, 'detail' => $detail, 'prenom' => $refus['prenom'] ?? '']);
            }
            json_sortie(['etat' => 'attente', 'actif' => (bool)$lecteur['actif']]);
        }
        $lignes = [];
        foreach (lignes_disponibles($pdo, (int)$session['utilisateur_id']) as $l) {
            $et = etat_ligne($l);
            $lignes[] = [
                'id' => (int)$l['id'],
                'nom' => $l['nom'],
                'description' => $l['description'],
                'posologie' => $l['posologie'],
                'reste' => (int)$l['reste'],
                'stock' => (int)$l['stock'],
                'max' => $et['max'],
                'bloque' => $et['bloque'],
                'delai' => (int)$l['delai_minutes'] > 0 ? '1 prise toutes les ' . format_duree((int)$l['delai_minutes']) : '',
                'ordonnance' => (int)$l['ordonnance_id'],
                'medecin' => $l['medecin'] ?? '',
                'expiration' => date_fr($l['date_expiration'], false),
            ];
        }
        json_sortie([
            'etat' => 'patient',
            'patient' => $session['prenom'] . ' ' . $session['nom'],
            'badge' => $session['uid_badge'],
            'expire_dans' => max(0, (int)$session['reste']),
            'lignes' => $lignes,
        ]);
    }

    // ---- Délivrer : le patient valide sa sélection ----
    if ($action === 'delivrer') {
        if (!$session) json_sortie(['erreur' => 'Session terminée : repassez votre badge.'], 409);
        $patientId = (int)$session['utilisateur_id'];
        $choix = json_decode((string)($_POST['choix'] ?? '{}'), true);
        $choix = is_array($choix) ? array_filter(array_map('intval', $choix), fn($q) => $q > 0) : [];
        if (!$choix) json_sortie(['erreur' => 'Sélectionnez au moins un produit.'], 400);

        $pdo->beginTransaction();
        $ligneSt = $pdo->prepare("SELECT l.*, m.nom, m.stock, m.delai_minutes, o.id AS oid FROM ordonnance_lignes l
            JOIN ordonnances o ON o.id = l.ordonnance_id JOIN medicaments m ON m.id = l.medicament_id
            WHERE l.id = ? AND o.patient_id = ? AND o.statut = 'active' AND o.date_expiration >= CURDATE() AND m.actif = 1
            FOR UPDATE");
        $recap = [];
        $ordos = [];
        foreach ($choix as $ligneId => $q) {
            $ligneSt->execute([(int)$ligneId, $patientId]);
            $l = $ligneSt->fetch();
            if (!$l) { $pdo->rollBack(); json_sortie(['erreur' => 'Un produit ne fait plus partie de vos droits.'], 409); }
            $reste = (int)$l['quantite'] - (int)$l['delivre'];
            if ($q > $reste) { $pdo->rollBack(); json_sortie(['erreur' => 'Quantité trop élevée pour ' . $l['nom'] . " (droit restant : $reste)."], 409); }
            if ($q > (int)$l['stock']) { $pdo->rollBack(); json_sortie(['erreur' => 'Stock insuffisant pour ' . $l['nom'] . ' (' . (int)$l['stock'] . ' disponible).'], 409); }
            $ci = contre_indications($pdo, $patientId, (int)$l['medicament_id']);
            if ($ci) { $pdo->rollBack(); json_sortie(['erreur' => $l['nom'] . ' est contre-indiqué pour vous (' . implode(', ', $ci) . ').'], 409); }
            $delai = (int)$l['delai_minutes'];
            if ($delai > 0) {
                if ($q > 1) { $pdo->rollBack(); json_sortie(['erreur' => $l['nom'] . ' : une seule unité à la fois.'], 409); }
                $der = $pdo->prepare('SELECT MAX(date_heure) FROM delivrances WHERE patient_id = ? AND medicament_id = ?');
                $der->execute([$patientId, $l['medicament_id']]);
                $derniere = $der->fetchColumn();
                if ($derniere && strtotime($derniere) + $delai * 60 > time()) {
                    $pdo->rollBack();
                    json_sortie(['erreur' => texte_attente(strtotime($derniere) + $delai * 60, $l['nom']) . '.'], 409);
                }
            }

            $pdo->prepare('UPDATE ordonnance_lignes SET delivre = delivre + ? WHERE id = ?')->execute([$q, $l['id']]);
            $pdo->prepare('UPDATE medicaments SET stock = stock - ? WHERE id = ?')->execute([$q, $l['medicament_id']]);
            $pdo->prepare('INSERT INTO delivrances (date_heure, patient_id, medicament_id, ligne_id, quantite, lecteur_id, compte_id) VALUES (NOW(), ?, ?, ?, ?, ?, ?)')
                ->execute([$patientId, $l['medicament_id'], $l['id'], $q, $lecteurId, est_connecte() ? (int)$_SESSION['admin_id'] : null]);
            $pdo->prepare("INSERT INTO logs (date_heure, uid_badge, utilisateur_id, lecteur_id, medicament_id, resultat, motif) VALUES (NOW(), ?, ?, ?, ?, 'autorise', ?)")
                ->execute([$session['uid_badge'], $patientId, $lecteurId, $l['medicament_id'], 'Délivré : ' . $l['nom'] . " ×$q (ordonnance #" . $l['oid'] . ')']);
            $recap[] = ['nom' => $l['nom'], 'quantite' => $q,
                'prochaine' => (int)$l['delai_minutes'] > 0 ? 'prochaine prise dans ' . format_duree((int)$l['delai_minutes']) . ', à partir de ' . date('H:i', time() + (int)$l['delai_minutes'] * 60) : ''];
            $ordos[(int)$l['oid']] = true;
        }
        // Ordonnance entièrement délivrée -> statut "terminee"
        $fin = $pdo->prepare("UPDATE ordonnances SET statut = 'terminee' WHERE id = ? AND statut = 'active'
            AND NOT EXISTS (SELECT 1 FROM ordonnance_lignes WHERE ordonnance_id = ? AND delivre < quantite)");
        foreach (array_keys($ordos) as $oid) $fin->execute([$oid, $oid]);
        $pdo->prepare('DELETE FROM borne_sessions WHERE lecteur_id = ?')->execute([$lecteurId]);
        $pdo->commit();
        json_sortie(['ok' => true, 'recap' => $recap, 'patient' => $session['prenom']]);
    }

    json_sortie(['erreur' => 'Action inconnue.'], 400);
} catch (Throwable $ex) {
    if (isset($pdo) && $pdo->inTransaction()) $pdo->rollBack();
    error_log('borne_api : ' . $ex->getMessage());
    json_sortie(['erreur' => 'Erreur serveur : ' . $ex->getMessage()], 500);
}
