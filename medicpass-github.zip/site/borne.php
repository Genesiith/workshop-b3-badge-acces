<?php
require __DIR__ . '/includes/init.php';
$pdo = db();

// Écran par défaut du site : sans connexion, écran pharmacie verrouillé, sans aucun lien
$kiosque = !est_connecte();
if (!$kiosque) require_role('admin', 'pharmacien');

$lecteurId = $kiosque ? borne_lecteur($pdo) : (int)($_GET['lecteur'] ?? 0);
$bornes = $pdo->query("SELECT id, nom, emplacement, actif FROM lecteurs ORDER BY nom")->fetchAll();
$lecteur = null;
foreach ($bornes as $b) if ((int)$b['id'] === $lecteurId) $lecteur = $b;
if (!$kiosque && !$lecteur && count($bornes) === 1) redirect('borne.php?lecteur=' . (int)$bornes[0]['id']);
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Medic Pass</title>
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="hud borne<?= $kiosque ? ' kiosque' : '' ?>"<?= $kiosque ? ' oncontextmenu="return false"' : '' ?>>
<header class="borne-barre">
  <div class="marque"><span class="logo" aria-hidden="true"></span><span>MEDIC<b>PASS</b></span><span class="borne-lieu"><?= $lecteur ? (stripos($lecteur['nom'], 'pharmacie') !== false ? e($lecteur['nom']) : 'Pharmacie · ' . e($lecteur['nom'])) : 'Pharmacie' ?></span></div>
  <div class="borne-droite">
    <span class="horloge mono" id="horloge"></span>
    <?php if (!$kiosque): ?>
      <?php if (role() === 'admin'): ?><a href="tableau.php">Retour admin</a><?php endif; ?>
      <a href="logout.php">Verrouiller</a>
    <?php endif; ?>
  </div>
</header>

<?php if (!$lecteur && $kiosque): ?>
  <main class="borne-centre">
    <section class="vue">
      <div class="croix-refus" aria-hidden="true"></div>
      <h1 class="borne-titre">Borne hors service</h1>
      <p class="borne-sous">Aucun lecteur n'est associé à cet écran. Adressez-vous au comptoir.</p>
    </section>
  </main>
<?php elseif (!$lecteur): ?>
  <main class="borne-centre">
    <section class="panneau borne-choix">
      <div class="panneau-tete"><h2>Choisir la borne de cet écran</h2></div>
      <?php if (!$bornes): ?>
        <p class="vide">Aucun lecteur enregistré. <?= role() === 'admin' ? '<a href="lecteurs.php">Créez-en un dans Lecteurs</a>.' : "Demandez à l'administrateur d'en créer un." ?></p>
      <?php else: ?>
        <p class="muted">Cet écran affichera les ordonnances des badges passés sur le lecteur choisi.</p>
        <div class="liste-bornes">
          <?php foreach ($bornes as $b): ?>
            <a class="btn btn-large" href="borne.php?lecteur=<?= (int)$b['id'] ?>"><?= e($b['nom']) ?><?= $b['emplacement'] ? ' · ' . e($b['emplacement']) : '' ?></a>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
  </main>
<?php else: ?>
  <main class="borne-centre" id="ecran" aria-live="polite">
    <!-- Attente d'un badge -->
    <section id="vue-attente" class="vue">
      <div class="scanner" aria-hidden="true"><span></span><span></span><span></span><i></i></div>
      <h1 class="borne-titre">Présentez votre badge</h1>
      <p class="borne-sous">Posez-le à plat sur le lecteur pour afficher vos médicaments prescrits.</p>
      <?php if (!$lecteur['actif']): ?><div class="alerte alerte-attention">Ce lecteur est désactivé dans l'administration.</div><?php endif; ?>
    </section>

    <!-- Patient identifié -->
    <section id="vue-patient" class="vue" hidden>
      <div class="patient-tete">
        <div>
          <div class="fil">IDENTIFICATION CONFIRMÉE</div>
          <h1 class="borne-titre" id="patient-nom"></h1>
          <p class="borne-sous">Choisissez les produits que vous souhaitez retirer aujourd'hui.</p>
        </div>
        <div class="minuteur"><span class="mono" id="minuteur">3:00</span><div class="jauge"><span id="minuteur-jauge"></span></div></div>
      </div>
      <div class="produits" id="produits"></div>
      <div class="borne-actions">
        <button type="button" class="btn btn-large" id="btn-annuler">Annuler</button>
        <button type="button" class="btn btn-primaire btn-large" id="btn-valider" disabled>Valider ma sélection</button>
      </div>
    </section>

    <!-- Délivrance confirmée -->
    <section id="vue-fin" class="vue" hidden>
      <div class="coche" aria-hidden="true"></div>
      <h1 class="borne-titre">Délivrance validée</h1>
      <p class="borne-sous">Merci <span id="fin-nom"></span>, vos produits vous sont remis au comptoir.</p>
      <ul class="recap" id="fin-recap"></ul>
    </section>

    <!-- Alarme anti-abus -->
    <section id="vue-alerte" class="vue" hidden>
      <div class="sirene-ecran" aria-hidden="true">☢</div>
      <h1 class="borne-titre">Alerte</h1>
      <p class="borne-sous">Tentatives répétées détectées. Un responsable va intervenir.</p>
    </section>

    <!-- Badge refusé -->
    <section id="vue-refus" class="vue" hidden>
      <div class="croix-refus" aria-hidden="true"></div>
      <h1 class="borne-titre" id="refus-titre"></h1>
      <p class="borne-sous" id="refus-detail"></p>
    </section>

    <div class="alerte alerte-erreur toast" id="toast" hidden></div>
  </main>

  <script>
  (function () {
    var LECTEUR = <?= (int)$lecteur['id'] ?>;
    var CSRF = <?= json_encode(csrf_token()) ?>;
    var vues = { attente: $('vue-attente'), patient: $('vue-patient'), fin: $('vue-fin'), refus: $('vue-refus'), alerte: $('vue-alerte') };
    var cle = null, choix = {}, finJusqua = 0, expireA = 0, dureeInit = 180, occupe = false;

    function $(id) { return document.getElementById(id); }
    function montrer(nom) { for (var k in vues) vues[k].hidden = (k !== nom); }
    function toast(msg) {
      var t = $('toast'); t.textContent = msg; t.hidden = false;
      clearTimeout(toast.t); toast.t = setTimeout(function () { t.hidden = true; }, 5000);
    }
    function el(tag, cls, txt) { var n = document.createElement(tag); if (cls) n.className = cls; if (txt != null) n.textContent = txt; return n; }

    function afficherPatient(d) {
      $('patient-nom').textContent = 'Bonjour ' + d.patient;
      var zone = $('produits'); zone.textContent = ''; choix = {};
      d.lignes.forEach(function (l) {
        var carte = el('article', 'produit' + (l.max === 0 ? ' indispo' : '') + (l.bloque && l.bloque.indexOf('Contre') === 0 ? ' contre' : ''));
        var haut = el('div', 'produit-haut');
        haut.appendChild(el('h2', null, l.nom));
        if (l.description) haut.appendChild(el('p', 'muted', l.description));
        carte.appendChild(haut);
        if (l.posologie) carte.appendChild(el('p', 'posologie', l.posologie));
        if (l.delai) carte.appendChild(el('p', 'delai mono', l.delai));
        var infos = el('dl', 'produit-infos');
        [['Droit restant', l.reste], ['En stock', l.stock], ['Ordonnance', '#' + l.ordonnance + (l.medecin ? ' · ' + l.medecin : '')], ['Valable jusqu\'au', l.expiration]]
          .forEach(function (p) { var dv = el('div'); dv.appendChild(el('dt', null, p[0])); dv.appendChild(el('dd', 'mono', String(p[1]))); infos.appendChild(dv); });
        carte.appendChild(infos);
        if (l.max === 0) {
          carte.appendChild(el('p', 'rupture', l.bloque || 'Indisponible'));
        } else {
          var pas = el('div', 'stepper');
          var moins = el('button', 'btn', '−'), val = el('output', 'mono', '0'), plus = el('button', 'btn', '+');
          moins.type = plus.type = 'button';
          moins.setAttribute('aria-label', 'Retirer une unité de ' + l.nom);
          plus.setAttribute('aria-label', 'Ajouter une unité de ' + l.nom);
          function maj(n) {
            n = Math.max(0, Math.min(l.max, n));
            if (n) choix[l.id] = n; else delete choix[l.id];
            val.textContent = n; carte.classList.toggle('choisi', n > 0);
            moins.disabled = n === 0; plus.disabled = n === l.max;
            $('btn-valider').disabled = Object.keys(choix).length === 0;
          }
          moins.onclick = function () { maj((choix[l.id] || 0) - 1); };
          plus.onclick = function () { maj((choix[l.id] || 0) + 1); };
          pas.appendChild(moins); pas.appendChild(val); pas.appendChild(plus);
          carte.appendChild(pas);
          maj(0);
        }
        zone.appendChild(carte);
      });
      $('btn-valider').disabled = true;
    }

    function tickMinuteur() {
      if (vues.patient.hidden) return;
      var s = Math.max(0, Math.round((expireA - Date.now()) / 1000));
      $('minuteur').textContent = Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
      $('minuteur-jauge').style.width = Math.min(100, s * 100 / dureeInit) + '%';
    }

    function interroger() {
      if (occupe || Date.now() < finJusqua) return;
      fetch('borne_api.php?action=etat&lecteur=' + LECTEUR, { credentials: 'same-origin', cache: 'no-store' })
        .then(function (r) {
          return r.text().then(function (t) {
            try { return JSON.parse(t); }
            catch (e) { console.error('Réponse du serveur :', t); return { erreur: 'Réponse invalide du serveur (code ' + r.status + ') : ' + t.replace(/<[^>]*>/g, ' ').trim().slice(0, 160) }; }
          });
        })
        .then(function (d) {
          if (d.erreur) { toast(d.erreur); return; }
          if (d.etat === 'admin') {
            occupe = true;
            $('refus-titre').textContent = 'Accès ' + (d.profil || 'administrateur').toLowerCase();
            $('refus-detail').textContent = 'Badge reconnu' + (d.compte ? ' : ' + d.compte : '') + '. Ouverture…';
            vues.refus.classList.add('vue-admin');
            montrer('refus');
            location.href = 'deverrouiller.php?l=' + LECTEUR + '&t=' + encodeURIComponent(d.jeton);
            return;
          }
          document.body.classList.toggle('en-alerte', d.etat === 'alerte');
          if (d.etat === 'alerte') { cle = null; finJusqua = 0; montrer('alerte'); return; }
          if (d.etat === 'attente') { cle = null; montrer('attente'); return; }
          if (d.etat === 'refus') {
            cle = null;
            $('refus-titre').textContent = (d.prenom ? d.prenom + ', ' : '') + d.titre.charAt(0).toLowerCase() + d.titre.slice(1);
            if (!d.prenom) $('refus-titre').textContent = d.titre;
            $('refus-detail').textContent = d.detail;
            montrer('refus'); return;
          }
          expireA = Date.now() + d.expire_dans * 1000;
          var nouvelleCle = d.badge + '|' + d.patient;
          if (nouvelleCle !== cle) { cle = nouvelleCle; dureeInit = Math.max(d.expire_dans, 1); afficherPatient(d); montrer('patient'); }
        })
        .catch(function () { toast('Connexion au serveur perdue, nouvelle tentative…'); });
    }

    function envoyer(action, extra) {
      var corps = new URLSearchParams({ action: action, lecteur: LECTEUR, csrf: CSRF });
      for (var k in (extra || {})) corps.append(k, extra[k]);
      return fetch('borne_api.php', { method: 'POST', credentials: 'same-origin', body: corps }).then(function (r) { return r.json(); });
    }

    $('btn-valider').onclick = function () {
      if (!Object.keys(choix).length) return;
      occupe = true; this.disabled = true;
      envoyer('delivrer', { choix: JSON.stringify(choix) }).then(function (d) {
        occupe = false;
        if (d.erreur) { toast(d.erreur); cle = null; interroger(); return; }
        $('fin-nom').textContent = d.patient;
        var ul = $('fin-recap'); ul.textContent = '';
        d.recap.forEach(function (r) {
          var li = el('li', null, r.nom + '  ×' + r.quantite);
          if (r.prochaine) li.appendChild(el('span', 'recap-delai', r.prochaine));
          ul.appendChild(li);
        });
        cle = null; finJusqua = Date.now() + 8000; montrer('fin');
      }).catch(function () { occupe = false; toast('Envoi impossible, réessayez.'); $('btn-valider').disabled = false; });
    };
    $('btn-annuler').onclick = function () {
      occupe = true;
      envoyer('annuler').then(function () { occupe = false; cle = null; montrer('attente'); })
        .catch(function () { occupe = false; });
    };

    function horloge() { $('horloge').textContent = new Date().toLocaleTimeString('fr-FR'); }
    horloge(); setInterval(horloge, 1000);
    setInterval(tickMinuteur, 500);
    interroger(); setInterval(interroger, 1500);
  })();
  </script>
<?php endif; ?>
<?php if (!$lecteur): ?>
<script>(function(){var h=document.getElementById('horloge');function t(){h.textContent=new Date().toLocaleTimeString('fr-FR');}t();setInterval(t,1000);})();</script>
<?php endif; ?>
</body>
</html>
