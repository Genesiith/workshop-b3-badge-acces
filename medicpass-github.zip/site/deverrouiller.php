<?php
// Ouverture de l'administration après passage du badge admin sur la borne
require __DIR__ . '/includes/init.php';
$pdo = db();

$lecteurId = (int)($_GET['l'] ?? 0);
$jeton = (string)($_GET['t'] ?? '');
$ok = false;

if ($lecteurId > 0 && $lecteurId === borne_lecteur($pdo) && $jeton !== '') {
    [$attendu, $quand, $compteId] = array_pad(explode('|', (string)param_get($pdo, 'deverrou_' . $lecteurId, '')), 3, '');
    if ($attendu !== '' && hash_equals($attendu, $jeton) && time() - (int)$quand <= 30) {
        param_set($pdo, 'deverrou_' . $lecteurId, '');   // jeton à usage unique
        $st = $pdo->prepare('SELECT id, identifiant, role FROM admins WHERE id = ?');
        $st->execute([(int)$compteId]);
        $compte = $st->fetch();
        if ($compte && isset(ROLES[$compte['role']])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int)$compte['id'];
            $_SESSION['admin_nom'] = $compte['identifiant'];
            $_SESSION['role'] = $compte['role'];
            flash('succes', 'Badge ' . ROLES[$compte['role']] . ' reconnu : bonjour ' . $compte['identifiant'] . '. Pensez à « Verrouiller » en partant.');
            $ok = true;
        }
    }
}
redirect($ok ? page_accueil() : 'borne.php');
