<?php
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/page_simple.php';
require __DIR__ . '/includes/comptes_defaut.php';
check_csrf();

$etat = '';
$message = '';
try {
    $pdo = db();
    try {
        $deja = (int)$pdo->query('SELECT COUNT(*) FROM admins')->fetchColumn() > 0;
    } catch (PDOException $ex) {
        $deja = false;
    }
    if ($deja) {
        $etat = 'deja';
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $identifiant = trim($_POST['identifiant'] ?? '');
        $mdp = (string)($_POST['mot_de_passe'] ?? '');
        if (strlen($identifiant) < 3 || strlen($mdp) < 8) {
            $message = "L'identifiant doit faire au moins 3 caractères et le mot de passe au moins 8.";
        } else {
            foreach (require __DIR__ . '/includes/schema.php' as $sql) {
                $pdo->exec($sql);
            }
            $pdo->prepare("INSERT INTO admins (identifiant, mot_de_passe, role) VALUES (?, ?, 'admin')")
                ->execute([$identifiant, password_hash($mdp, PASSWORD_DEFAULT)]);
            creer_compte_medecin($pdo);
            $etat = 'fait';
        }
    }
} catch (PDOException $ex) {
    $etat = 'erreur';
    $message = $ex->getMessage();
}

page_simple_debut('Installation');
if ($etat === 'erreur'): ?>
    <div class="alerte alerte-erreur">Connexion à la base impossible : <?= e($message) ?></div>
    <p>Vérifiez les informations de la base dans <code>config.php</code>, puis rechargez cette page.</p>
<?php elseif ($etat === 'deja'): ?>
    <div class="alerte alerte-info">Le site est déjà installé.</div>
    <p>Pour passer à la nouvelle version, ouvrez <a href="mise-a-jour.php">mise-a-jour.php</a>. Puis supprimez <code>install.php</code> du serveur.</p>
<?php elseif ($etat === 'fait'): ?>
    <div class="alerte alerte-succes">Base créée. Comptes enregistrés : votre administrateur, et le compte médecin « Medecin ».</div>
    <p><strong>Supprimez maintenant <code>install.php</code> et <code>mise-a-jour.php</code></strong> du serveur, puis <a href="login.php">connectez-vous</a>.</p>
<?php else: ?>
    <p>La connexion à la base fonctionne. Choisissez le compte du premier administrateur.</p>
    <?php if ($message): ?><div class="alerte alerte-erreur"><?= e($message) ?></div><?php endif; ?>
    <form method="post" class="formulaire">
      <?= csrf_field() ?>
      <label>Identifiant<input name="identifiant" required minlength="3"></label>
      <label>Mot de passe (8 caractères minimum)<input type="password" name="mot_de_passe" required minlength="8"></label>
      <button class="btn btn-primaire btn-large">Installer le site</button>
    </form>
<?php endif;
page_simple_fin();
