<?php
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/page_simple.php';
check_csrf();

if (est_connecte()) redirect(page_accueil());

$erreur = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifiant = trim($_POST['identifiant'] ?? '');
    $mdp = (string)($_POST['mot_de_passe'] ?? '');
    try {
        $st = db()->prepare('SELECT * FROM admins WHERE identifiant = ?');
        $st->execute([$identifiant]);
        $compte = $st->fetch();
        if ($compte && password_verify($mdp, $compte['mot_de_passe'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id'] = (int)$compte['id'];
            $_SESSION['admin_nom'] = $compte['identifiant'];
            $_SESSION['role'] = isset(ROLES[$compte['role'] ?? '']) ? $compte['role'] : 'admin';
            redirect(page_accueil());
        }
        sleep(1);
        $erreur = 'Identifiant ou mot de passe incorrect.';
    } catch (PDOException $ex) {
        $erreur = "Connexion à la base impossible. Vérifiez config.php, puis lancez install.php si ce n'est pas déjà fait.";
    }
}

page_simple_debut('Authentification');
?>
    <?php if ($erreur): ?><div class="alerte alerte-erreur"><?= e($erreur) ?></div><?php endif; ?>
    <form method="post" class="formulaire">
      <?= csrf_field() ?>
      <label>Identifiant<input name="identifiant" required autofocus autocomplete="username"></label>
      <label>Mot de passe<input type="password" name="mot_de_passe" required autocomplete="current-password"></label>
      <button class="btn btn-primaire btn-large" type="submit">Connexion</button>
    </form>
<?php page_simple_fin();
