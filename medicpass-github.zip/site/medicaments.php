<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
check_csrf();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    try {
        if ($action === 'enregistrer') {
            $nom = trim($_POST['nom'] ?? '');
            $desc = trim($_POST['description'] ?? '');
            $stock = max(0, (int)($_POST['stock'] ?? 0));
            $delai = max(0, (int)round((float)str_replace(',', '.', (string)($_POST['delai_heures'] ?? '0')) * 60));
            $interdits = array_unique(array_map('intval', (array)($_POST['interdit'] ?? [])));
            if ($nom === '') {
                flash('erreur', 'Le nom du médicament est obligatoire.');
            } else {
                $pdo->beginTransaction();
                if ($id > 0) {
                    $pdo->prepare('UPDATE medicaments SET nom = ?, description = ?, stock = ?, delai_minutes = ? WHERE id = ?')
                        ->execute([$nom, $desc, $stock, $delai, $id]);
                } else {
                    $pdo->prepare('INSERT INTO medicaments (nom, description, stock, delai_minutes) VALUES (?, ?, ?, ?)')
                        ->execute([$nom, $desc, $stock, $delai]);
                    $id = (int)$pdo->lastInsertId();
                }
                $pdo->prepare('DELETE FROM medicament_contre_indications WHERE medicament_id = ?')->execute([$id]);
                $ins = $pdo->prepare('INSERT INTO medicament_contre_indications (medicament_id, condition_id) VALUES (?, ?)');
                foreach ($interdits as $cid) if ($cid > 0) $ins->execute([$id, $cid]);
                $pdo->commit();
                flash('succes', "$nom enregistré.");
            }
        } elseif ($action === 'stock') {
            $delta = (int)($_POST['delta'] ?? 0);
            $pdo->prepare('UPDATE medicaments SET stock = GREATEST(0, stock + ?) WHERE id = ?')->execute([$delta, $id]);
            flash('succes', 'Stock mis à jour.');
        } elseif ($action === 'basculer') {
            $pdo->prepare('UPDATE medicaments SET actif = 1 - actif WHERE id = ?')->execute([$id]);
            flash('succes', 'Statut du médicament modifié.');
        } elseif ($action === 'supprimer') {
            $pdo->prepare('DELETE FROM medicaments WHERE id = ?')->execute([$id]);
            flash('succes', 'Médicament supprimé (et retiré des ordonnances).');
        } elseif ($action === 'ajouter_condition') {
            $nomC = normaliser_condition((string)($_POST['condition'] ?? ''));
            if ($nomC !== '') {
                $pdo->prepare('INSERT IGNORE INTO conditions (nom) VALUES (?)')->execute([$nomC]);
                flash('succes', "Condition « $nomC » disponible.");
            }
        } elseif ($action === 'supprimer_condition') {
            $pdo->prepare('DELETE FROM conditions WHERE id = ?')->execute([$id]);
            flash('succes', 'Condition supprimée (retirée des patients et des médicaments).');
        }
    } catch (PDOException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('erreur', 'Erreur de base de données : ' . $ex->getMessage());
    }
    redirect('medicaments.php');
}

$edit = null;
$interditsEdit = [];
if (isset($_GET['edit'])) {
    $st = $pdo->prepare('SELECT * FROM medicaments WHERE id = ?');
    $st->execute([(int)$_GET['edit']]);
    $edit = $st->fetch() ?: null;
    if ($edit) {
        $st = $pdo->prepare('SELECT condition_id FROM medicament_contre_indications WHERE medicament_id = ?');
        $st->execute([(int)$edit['id']]);
        $interditsEdit = array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    }
}
$conditions = $pdo->query('SELECT c.id, c.nom,
        (SELECT COUNT(*) FROM patient_conditions pc WHERE pc.condition_id = c.id) AS patients,
        (SELECT COUNT(*) FROM medicament_contre_indications mc WHERE mc.condition_id = c.id) AS meds
    FROM conditions c ORDER BY c.nom')->fetchAll();
$meds = $pdo->query("SELECT m.*, (SELECT GROUP_CONCAT(c.nom ORDER BY c.nom SEPARATOR ', ')
        FROM medicament_contre_indications mc JOIN conditions c ON c.id = mc.condition_id WHERE mc.medicament_id = m.id) AS interdits
    FROM medicaments m ORDER BY m.nom")->fetchAll();

$title = 'Médicaments';
$page = 'medicaments';
require __DIR__ . '/includes/header.php';
?>
<section class="panneau">
  <div class="panneau-tete"><h2><?= $edit ? 'Modifier ' . e($edit['nom']) : 'Nouveau médicament' ?></h2></div>
  <form method="post" class="formulaire formulaire-large">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="enregistrer">
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="ligne2">
      <label>Nom<input name="nom" value="<?= e($edit['nom'] ?? '') ?>" required placeholder="Doliprane 500 mg"></label>
      <label>Description<input name="description" value="<?= e($edit['description'] ?? '') ?>" placeholder="Boîte de 16 comprimés"></label>
    </div>
    <div class="ligne2">
      <label>Stock (boîtes)<input type="number" name="stock" min="0" value="<?= (int)($edit['stock'] ?? 0) ?>"></label>
      <label>Délai entre deux prises (heures, 0 = aucun)<input type="number" name="delai_heures" min="0" step="0.25" value="<?= e(rtrim(rtrim(number_format(((int)($edit['delai_minutes'] ?? 0)) / 60, 2, '.', ''), '0'), '.')) ?>"></label>
    </div>
    <fieldset>
      <legend>Interdit pour les patients avec la condition</legend>
      <?php if (!$conditions): ?>
        <p class="vide">Aucune condition enregistrée. Ajoutez-en dans le cadre « Conditions médicales » plus bas, ou depuis le dossier d'un patient.</p>
      <?php else: ?>
        <div class="cases-grille">
          <?php foreach ($conditions as $c): ?>
            <label class="case"><input type="checkbox" name="interdit[]" value="<?= (int)$c['id'] ?>" <?= in_array((int)$c['id'], $interditsEdit, true) ? 'checked' : '' ?>> <?= e($c['nom']) ?></label>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </fieldset>
    <p class="muted">Avec un délai, le patient ne peut retirer qu'une unité à la fois, puis doit attendre avant la suivante.</p>
    <div class="actions">
      <button class="btn btn-primaire"><?= $edit ? 'Enregistrer les modifications' : 'Ajouter le médicament' ?></button>
      <?php if ($edit): ?><a class="btn" href="medicaments.php">Annuler</a><?php endif; ?>
    </div>
  </form>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2>Inventaire (<?= count($meds) ?>)</h2></div>
  <?php if (!$meds): ?>
    <p class="vide">Aucun médicament. Ajoutez-en un avec le formulaire ci-dessus.</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Médicament</th><th class="num">Stock</th><th>Délai</th><th>Interdit pour</th><th>Réapprovisionner</th><th>Statut</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($meds as $m): ?>
      <tr>
        <td><strong><?= e($m['nom']) ?></strong><?= $m['description'] ? '<br><span class="muted">' . e($m['description']) . '</span>' : '' ?></td>
        <td class="num mono"><span class="<?= $m['stock'] <= STOCK_ALERTE ? 'stock-bas' : '' ?>"><?= (int)$m['stock'] ?></span></td>
        <td class="mono"><?= $m['delai_minutes'] > 0 ? e(format_duree((int)$m['delai_minutes'])) : '<span class="muted">—</span>' ?></td>
        <td><?= $m['interdits'] ? '<span class="tag ko">' . e($m['interdits']) . '</span>' : '<span class="muted">—</span>' ?></td>
        <td>
          <form method="post" class="inline ligne-stock">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="stock">
            <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
            <input type="number" name="delta" value="10" aria-label="Quantité à ajouter (négatif pour retirer)">
            <button class="btn btn-sm">Ajouter</button>
          </form>
        </td>
        <td><?= $m['actif'] ? '<span class="tag ok">Actif</span>' : '<span class="tag neutre">Désactivé</span>' ?></td>
        <td class="actions">
          <a class="btn btn-sm" href="medicaments.php?edit=<?= (int)$m['id'] ?>">Modifier</a>
          <?= action_btn('basculer', (int)$m['id'], $m['actif'] ? 'Désactiver' : 'Activer') ?>
          <?= action_btn('supprimer', (int)$m['id'], 'Supprimer', 'btn-danger', 'Supprimer ' . $m['nom'] . ' ? Il sera retiré des ordonnances.') ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2>Conditions médicales (<?= count($conditions) ?>)</h2><span class="muted">Créées ici ou depuis le dossier d'un patient, sans doublon</span></div>
  <form method="post" class="recherche">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="ajouter_condition">
    <input name="condition" required maxlength="80" placeholder="Nouvelle condition, ex. Insuffisance rénale" aria-label="Nouvelle condition">
    <button class="btn btn-sm btn-primaire">Ajouter</button>
  </form>
  <?php if ($conditions): ?>
  <div class="table-wrap mt"><table>
    <thead><tr><th>Condition</th><th class="num">Patients</th><th class="num">Médicaments interdits</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($conditions as $c): ?>
      <tr>
        <td><?= e($c['nom']) ?></td>
        <td class="num mono"><?= (int)$c['patients'] ?></td>
        <td class="num mono"><?= (int)$c['meds'] ?></td>
        <td class="actions"><?= action_btn('supprimer_condition', (int)$c['id'], 'Supprimer', 'btn-danger', 'Supprimer « ' . $c['nom'] . ' » ? Elle sera retirée de tous les patients et médicaments.') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
