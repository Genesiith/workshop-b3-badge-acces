<?php
// Nouvelles lignes du journal, pour le rafraîchissement automatique (appelé en JavaScript)
ini_set('display_errors', '0');
ob_start();
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/filtres_logs.php';
header('Content-Type: application/json; charset=utf-8');

function flux_sortie(array $d, int $code = 200): void
{
    while (ob_get_level()) ob_end_clean();
    http_response_code($code);
    echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!est_connecte() || role() !== 'admin') flux_sortie(['erreur' => 'Session expirée'], 401);

try {
    $pdo = db();
    [$where, $params] = filtres_logs($_GET);
    $after = max(0, (int)($_GET['after'] ?? 0));

    $sqlTotal = 'SELECT COUNT(*) FROM logs l LEFT JOIN utilisateurs u ON u.id = l.utilisateur_id'
        . ($where ? ' WHERE ' . implode(' AND ', $where) : '');
    $st = $pdo->prepare($sqlTotal);
    $st->execute($params);
    $total = (int)$st->fetchColumn();

    $where[] = 'l.id > ?';
    $params[] = $after;
    $st = $pdo->prepare(LOGS_SELECT . ' WHERE ' . implode(' AND ', $where) . ' ORDER BY l.id ASC LIMIT 50');
    $st->execute($params);

    $lignes = [];
    foreach ($st->fetchAll() as $r) {
        $lignes[] = ['id' => (int)$r['id'], 'html' => ligne_log_html($r, true)];
    }
    flux_sortie(['total' => $total, 'lignes' => $lignes]);
} catch (Throwable $ex) {
    error_log('logs_flux : ' . $ex->getMessage());
    flux_sortie(['erreur' => 'Erreur serveur'], 500);
}
