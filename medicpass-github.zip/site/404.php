<?php
// Page affichée quand l'adresse demandée n'existe pas
require __DIR__ . '/includes/init.php';
http_response_code(404);
$retour = est_connecte() ? page_accueil() : 'borne.php';
$libelle = est_connecte() ? 'Retour à mon espace' : 'Retour à la pharmacie';
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Medic Pass</title>
<link rel="icon" type="image/svg+xml" href="/assets/favicon.svg">
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/assets/style.css">
<meta http-equiv="refresh" content="10; url=<?= e($retour) ?>">
</head>
<body class="hud borne">
<header class="borne-barre">
  <div class="marque"><span class="logo" aria-hidden="true"></span><span>MEDIC<b>PASS</b></span><span class="borne-lieu">Erreur 404</span></div>
  <div class="borne-droite"><span class="horloge mono" id="horloge"></span></div>
</header>
<main class="borne-centre">
  <section class="vue">
    <p class="erreur-404" aria-hidden="true">404</p>
    <h1 class="borne-titre">Page introuvable</h1>
    <p class="borne-sous">Cette adresse n'existe pas sur Medic Pass. Vérifiez l'orthographe du lien.</p>
    <p class="muted mono" id="compte-a-rebours">Redirection automatique dans 10 secondes…</p>
    <div class="borne-actions" style="justify-content:center">
      <a class="btn btn-primaire btn-large" href="<?= e($retour) ?>"><?= e($libelle) ?></a>
    </div>
  </section>
</main>
<script>
(function () {
  var h = document.getElementById('horloge');
  function t() { h.textContent = new Date().toLocaleTimeString('fr-FR'); }
  t(); setInterval(t, 1000);
  var n = 10, c = document.getElementById('compte-a-rebours');
  setInterval(function () {
    n--;
    if (n > 0) c.textContent = 'Redirection automatique dans ' + n + ' seconde' + (n > 1 ? 's' : '') + '…';
    else c.textContent = 'Redirection…';
  }, 1000);
})();
</script>
</body>
</html>
