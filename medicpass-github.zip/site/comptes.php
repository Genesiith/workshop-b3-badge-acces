<?php
require __DIR__ . '/includes/init.php';
require_login();
check_csrf();
$pdo = db();
$moi = (int)$_SESSION['admin_id'];
$estAdmin = role() === 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    try {
        if ($action === 'motdepasse') {
            $st = $pdo->prepare('SELECT mot_de_passe FROM admins WHERE id = ?');
            $st->execute([$moi]);
            $hash = (string)$st->fetchColumn();
            $nouveau = (string)($_POST['nouveau'] ?? '');
            if (!password_verify((string)($_POST['actuel'] ?? ''), $hash)) {
                flash('erreur', 'Le mot de passe actuel est incorrect.');
            } elseif (strlen($nouveau) < 8) {
                flash('erreur', 'Le nouveau mot de passe doit faire au moins 8 caractères.');
            } elseif ($nouveau !== ($_POST['confirmation'] ?? '')) {
                flash('erreur', 'La confirmation ne correspond pas au nouveau mot de passe.');
            } else {
                $pdo->prepare('UPDATE admins SET mot_de_passe = ? WHERE id = ?')->execute([password_hash($nouveau, PASSWORD_DEFAULT), $moi]);
                flash('succes', 'Mot de passe modifié.');
            }
        } elseif ($estAdmin && $action === 'ajouter') {
            $ident = trim($_POST['identifiant'] ?? '');
            $mdp = (string)($_POST['mot_de_passe'] ?? '');
            $r = isset(ROLES[$_POST['role'] ?? '']) ? $_POST['role'] : 'pharmacien';
            $badge = normalize_uid($_POST['uid_badge'] ?? '');
            $st = $pdo->prepare('SELECT COUNT(*) FROM utilisateurs WHERE uid_badge = ?');
            $st->execute([$badge]);
            if (strlen($ident) < 3 || strlen($mdp) < 8) {
                flash('erreur', "L'identifiant doit faire au moins 3 caractères et le mot de passe au moins 8.");
            } elseif ($badge !== '' && (int)$st->fetchColumn() > 0) {
                flash('erreur', 'Ce badge appartient déjà à un patient : utilisez un autre badge.');
            } else {
                $pdo->prepare('INSERT INTO admins (identifiant, mot_de_passe, role, uid_badge) VALUES (?, ?, ?, ?)')
                    ->execute([$ident, password_hash($mdp, PASSWORD_DEFAULT), $r, $badge !== '' ? $badge : null]);
                flash('succes', "Compte $ident (" . ROLES[$r] . ')' . ($badge !== '' ? " créé avec le badge $badge." : ' créé.'));
            }
        } elseif ($estAdmin && $action === 'modifier') {
            $ident = trim($_POST['identifiant'] ?? '');
            $mdp = (string)($_POST['mot_de_passe'] ?? '');
            if (strlen($ident) < 3) {
                flash('erreur', "L'identifiant doit faire au moins 3 caractères.");
                redirect('comptes.php?edit=' . $id);
            } elseif ($mdp !== '' && strlen($mdp) < 8) {
                flash('erreur', 'Le nouveau mot de passe doit faire au moins 8 caractères.');
                redirect('comptes.php?edit=' . $id);
            } elseif ($mdp !== '' && $mdp !== ($_POST['confirmation'] ?? '')) {
                flash('erreur', 'La confirmation ne correspond pas au nouveau mot de passe.');
                redirect('comptes.php?edit=' . $id);
            } else {
                $badge = normalize_uid($_POST['uid_badge'] ?? '');
                $st = $pdo->prepare('SELECT COUNT(*) FROM utilisateurs WHERE uid_badge = ?');
                $st->execute([$badge]);
                if ($badge !== '' && (int)$st->fetchColumn() > 0) {
                    flash('erreur', 'Ce badge appartient déjà à un patient : utilisez un autre badge.');
                    redirect('comptes.php?edit=' . $id);
                }
                $pdo->prepare('UPDATE admins SET identifiant = ?, uid_badge = ? WHERE id = ?')->execute([$ident, $badge !== '' ? $badge : null, $id]);
                if ($mdp !== '') {
                    $pdo->prepare('UPDATE admins SET mot_de_passe = ? WHERE id = ?')->execute([password_hash($mdp, PASSWORD_DEFAULT), $id]);
                }
                if ($id === $moi) $_SESSION['admin_nom'] = $ident;
                flash('succes', "Compte $ident modifié" . ($mdp !== '' ? ', nouveau mot de passe enregistré.' : '.'));
            }
        } elseif ($estAdmin && $action === 'role') {
            $r = $_POST['role'] ?? '';
            if ($id === $moi) {
                flash('erreur', 'Vous ne pouvez pas changer votre propre profil.');
            } elseif (isset(ROLES[$r])) {
                $pdo->prepare('UPDATE admins SET role = ? WHERE id = ?')->execute([$r, $id]);
                flash('succes', 'Profil modifié. Il prendra effet à sa prochaine connexion.');
            }
        } elseif ($estAdmin && $action === 'supprimer') {
            if ($id === $moi) {
                flash('erreur', 'Vous ne pouvez pas supprimer votre propre compte.');
            } else {
                $pdo->prepare('DELETE FROM admins WHERE id = ?')->execute([$id]);
                flash('succes', 'Compte supprimé.');
            }
        }
    } catch (PDOException $ex) {
        flash('erreur', $ex->getCode() == 23000 ? 'Cet identifiant existe déjà.' : 'Erreur de base de données : ' . $ex->getMessage());
    }
    redirect('comptes.php');
}

$comptes = $estAdmin ? $pdo->query("SELECT id, identifiant, role, uid_badge, cree_le FROM admins ORDER BY FIELD(role, 'admin', 'medecin', 'pharmacien'), identifiant")->fetchAll() : [];
// Badges vus récemment et associés à personne : proposés pour les comptes
$badgesLibres = $estAdmin ? $pdo->query("SELECT uid_badge, MAX(date_heure) AS vu FROM logs
    WHERE uid_badge NOT IN (SELECT uid_badge FROM utilisateurs WHERE uid_badge IS NOT NULL)
      AND uid_badge NOT IN (SELECT uid_badge FROM admins WHERE uid_badge IS NOT NULL)
    GROUP BY uid_badge ORDER BY vu DESC LIMIT 6")->fetchAll() : [];
$parRole = ['admin' => 0, 'medecin' => 0, 'pharmacien' => 0];
foreach ($comptes as $c) { if (isset($parRole[$c['role']])) $parRole[$c['role']]++; }
$edit = null;
if ($estAdmin && isset($_GET['edit'])) {
    $st = $pdo->prepare('SELECT id, identifiant, role, uid_badge FROM admins WHERE id = ?');
    $st->execute([(int)$_GET['edit']]);
    $edit = $st->fetch() ?: null;
}

$title = $estAdmin ? 'Comptes' : 'Mon compte';
$page = 'comptes';
require __DIR__ . '/includes/header.php';
?>
<?php if ($edit): ?>
<section class="panneau" id="modifier">
  <div class="panneau-tete"><h2>Modifier le compte <?= e($edit['identifiant']) ?></h2><span class="tag info"><?= e(ROLES[$edit['role']] ?? $edit['role']) ?></span></div>
  <form method="post" class="formulaire">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="modifier">
    <input type="hidden" name="id" value="<?= (int)$edit['id'] ?>">
    <label>Identifiant<input name="identifiant" value="<?= e($edit['identifiant']) ?>" required minlength="3" autocomplete="off"></label>
    <label>Badge de connexion (UID)<input class="mono badge-cible" name="uid_badge" value="<?= e($edit['uid_badge']) ?>" placeholder="91:A4:31:07"></label>
    <div class="ligne2">
      <label>Nouveau mot de passe<input type="password" name="mot_de_passe" minlength="8" autocomplete="new-password" placeholder="Laisser vide pour ne pas changer"></label>
      <label>Confirmer le mot de passe<input type="password" name="confirmation" minlength="8" autocomplete="new-password"></label>
    </div>
    <div class="actions">
      <button class="btn btn-primaire">Enregistrer</button>
      <a class="btn" href="comptes.php">Annuler</a>
    </div>
  </form>
</section>
<?php endif; ?>
<div class="grille">
  <?php if ($estAdmin): ?>
  <section class="panneau">
    <div class="panneau-tete"><h2>Nouveau compte</h2><span class="muted"><?= (int)$parRole['medecin'] ?> médecin<?= $parRole['medecin'] > 1 ? 's' : '' ?> · <?= (int)$parRole['pharmacien'] ?> pharmacien<?= $parRole['pharmacien'] > 1 ? 's' : '' ?> · <?= (int)$parRole['admin'] ?> admin<?= $parRole['admin'] > 1 ? 's' : '' ?></span></div>
    <p class="muted">Pour ajouter un médecin : un identifiant (par exemple « DrMartin »), un mot de passe d'au moins 8 caractères, le profil <strong>Médecin</strong>, et son <strong>badge</strong>. Il se connectera en passant son badge sur un lecteur ; le mot de passe reste une solution de secours sur <code>/login.php</code>.</p>
    <?php if ($badgesLibres): ?>
      <p class="muted">Badges vus récemment, libres — cliquez pour les utiliser :</p>
      <ul class="liste-badges">
        <?php foreach ($badgesLibres as $b): ?>
          <li><button type="button" class="btn btn-sm" onclick="remplirBadge(<?= e(json_encode($b['uid_badge'])) ?>)"><?= e($b['uid_badge']) ?></button><span class="muted mono"><?= e(date_fr($b['vu'], true, false)) ?></span></li>
        <?php endforeach; ?>
      </ul>
      <script>function remplirBadge(uid) { document.querySelectorAll('.badge-cible').forEach(function (i) { i.value = uid; }); }</script>
    <?php endif; ?>
    <form method="post" class="formulaire">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="ajouter">
      <label>Identifiant<input name="identifiant" required minlength="3" autocomplete="off" placeholder="DrMartin"></label>
      <label>Badge de connexion (UID, facultatif)<input class="mono badge-cible" name="uid_badge" placeholder="91:A4:31:07"></label>
      <label>Mot de passe (8 caractères minimum)<input type="password" name="mot_de_passe" required minlength="8" autocomplete="new-password"></label>
      <label>Profil
        <select name="role">
          <option value="medecin" selected>Médecin : ordonnances uniquement</option>
          <option value="pharmacien">Pharmacien : écran pharmacie uniquement</option>
          <option value="admin">Administrateur : accès complet</option>
        </select>
      </label>
      <button class="btn btn-primaire">Créer le compte</button>
    </form>
  </section>
  <?php endif; ?>
  <section class="panneau">
    <div class="panneau-tete"><h2>Changer mon mot de passe</h2></div>
    <form method="post" class="formulaire">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="motdepasse">
      <label>Mot de passe actuel<input type="password" name="actuel" required autocomplete="current-password"></label>
      <label>Nouveau mot de passe<input type="password" name="nouveau" required minlength="8" autocomplete="new-password"></label>
      <label>Confirmer le nouveau mot de passe<input type="password" name="confirmation" required minlength="8" autocomplete="new-password"></label>
      <button class="btn btn-primaire">Changer le mot de passe</button>
    </form>
  </section>
</div>

<?php if ($estAdmin): ?>
<section class="panneau">
  <div class="panneau-tete"><h2>Comptes (<?= count($comptes) ?>)</h2></div>
  <div class="table-wrap"><table>
    <thead><tr><th>Identifiant</th><th>Profil</th><th>Badge de connexion</th><th>Créé le</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($comptes as $c): $soi = (int)$c['id'] === $moi; ?>
      <tr>
        <td><?= e($c['identifiant']) ?><?= $soi ? ' <span class="tag neutre">vous</span>' : '' ?><?= $c['role'] === 'medecin' ? ' <span class="tag info">médecin</span>' : '' ?></td>
        <td>
          <?php if ($soi): ?><?= e(ROLES[$c['role']] ?? $c['role']) ?>
          <?php else: ?>
            <form method="post" class="inline ligne-stock">
              <?= csrf_field() ?>
              <input type="hidden" name="action" value="role">
              <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
              <select name="role" aria-label="Profil de <?= e($c['identifiant']) ?>">
                <?php foreach (ROLES as $k => $lib): ?><option value="<?= $k ?>" <?= $c['role'] === $k ? 'selected' : '' ?>><?= $lib ?></option><?php endforeach; ?>
              </select>
              <button class="btn btn-sm">Appliquer</button>
            </form>
          <?php endif; ?>
        </td>
        <td><?= $c['uid_badge'] ? '<code>' . e($c['uid_badge']) . '</code>' : '<span class="muted">Aucun</span>' ?></td>
        <td class="mono"><?= e(date_fr($c['cree_le'], false)) ?></td>
        <td class="actions">
          <a class="btn btn-sm" href="comptes.php?edit=<?= (int)$c['id'] ?>#modifier">Modifier</a>
          <?= $soi ? '' : action_btn('supprimer', (int)$c['id'], 'Supprimer', 'btn-danger', 'Supprimer le compte ' . $c['identifiant'] . ' ?') ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</section>
<?php endif; ?>
<?php require __DIR__ . '/includes/footer.php';
