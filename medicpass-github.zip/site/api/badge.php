<?php
// =====================================================
//  API appelée par les lecteurs (cartes NodeMCU)
//  POST uid=91:A4:31:07&lecteur=1&cle=xxxxxxxx
//  Réponse JSON : {"autorise":true,"message":"...","nom":"..."}
// =====================================================
define('NO_SESSION', true);
ini_set('display_errors', '0');
ob_start();
require __DIR__ . '/../includes/init.php';
header('Content-Type: application/json; charset=utf-8');

function repondre(bool $ok, string $msg, array $extra = [], int $code = 200): void
{
    while (ob_get_level()) ob_end_clean();
    http_response_code($code);
    echo json_encode(['autorise' => $ok, 'message' => $msg] + $extra, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function journaliser(PDO $pdo, string $uid, ?int $userId, int $lecteurId, bool $ok, string $motif): void
{
    $pdo->prepare('INSERT INTO logs (date_heure, uid_badge, utilisateur_id, lecteur_id, resultat, motif) VALUES (NOW(), ?, ?, ?, ?, ?)')
        ->execute([$uid, $userId, $lecteurId, $ok ? 'autorise' : 'refuse', $motif]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    repondre(false, 'Utilisez une requête POST', [], 405);
}

$input = $_POST;
if (!$input) {
    $json = json_decode((string)file_get_contents('php://input'), true);
    if (is_array($json)) $input = $json;
}

$uid = normalize_uid((string)($input['uid'] ?? ''));
$lecteurId = (int)($input['lecteur'] ?? 0);
$cle = (string)($input['cle'] ?? '');
if ($uid === '' || $lecteurId <= 0 || $cle === '') {
    repondre(false, 'Paramètres manquants (uid, lecteur, cle)', [], 400);
}

try {
    $pdo = db();

    $st = $pdo->prepare('SELECT * FROM lecteurs WHERE id = ?');
    $st->execute([$lecteurId]);
    $lecteur = $st->fetch();
    if (!$lecteur || !hash_equals($lecteur['cle_api'], $cle)) {
        repondre(false, 'Lecteur non reconnu (numéro ou clé incorrect)', [], 401);
    }
    $pdo->prepare('UPDATE lecteurs SET derniere_activite = NOW() WHERE id = ?')->execute([$lecteurId]);

    $userId = null;
    $extra = [];
    $refuser = function (string $motif) use (&$pdo, &$uid, &$userId, &$lecteurId, &$extra): void {
        journaliser($pdo, $uid, $userId, $lecteurId, false, $motif);
        // Anti-abus : trop de refus d'affilée pour ce badge -> alarme, arrêt uniquement au badge admin
        $seuil = (int)param_get($pdo, 'abus_seuil');
        if ($seuil > 0 && !alerte_etat($pdo, $lecteurId)['active']) {
            $n = refus_recents($pdo, $lecteurId, $uid, max(1, (int)param_get($pdo, 'abus_minutes')));
            if ($n >= $seuil) {
                param_set($pdo, 'alerte_' . $lecteurId, time() . '|abus');
                journaliser($pdo, $uid, $userId, $lecteurId, false, "ALERTE : $n tentatives refusées, alarme déclenchée (badge admin requis)");
                repondre(false, 'Alarme déclenchée : tentatives répétées', $extra + ['alerte' => 1]);
            }
        }
        repondre(false, $motif, $extra);
    };

    if (!$lecteur['actif']) $refuser('Lecteur désactivé');

    // ---- Badge d'un compte du site (administrateur ou médecin) : ouvre sa session ----
    if ($compte = compte_par_badge($pdo, $uid)) {
        $libelle = ROLES[$compte['role']] ?? $compte['role'];
        if ($compte['role'] === 'admin' && alerte_etat($pdo, $lecteurId)['active']) {
            alerte_arreter($pdo, $lecteurId);
            journaliser($pdo, $uid, null, $lecteurId, true, 'Alarme désactivée par badge administrateur');
        }
        if (alerte_etat($pdo, $lecteurId)['active']) {
            journaliser($pdo, $uid, null, $lecteurId, false, 'ALERTE en cours : seul un badge administrateur peut la lever');
            repondre(false, 'Alarme en cours : badge administrateur requis', ['alerte' => 1]);
        }
        param_set($pdo, 'deverrou_' . $lecteurId, bin2hex(random_bytes(16)) . '|' . time() . '|' . $compte['id']);
        $pdo->prepare('DELETE FROM borne_sessions WHERE lecteur_id = ?')->execute([$lecteurId]);
        journaliser($pdo, $uid, null, $lecteurId, true, 'Badge ' . $libelle . ' : connexion de ' . $compte['identifiant']);
        repondre(true, 'Accès ' . $libelle, ['nom' => $compte['identifiant'], 'profil' => $compte['role']]);
    }

    // ---- Alarme en cours : seul le badge administrateur est accepté ----
    if (alerte_etat($pdo, $lecteurId)['active']) {
        journaliser($pdo, $uid, null, $lecteurId, false, 'ALERTE en cours : badge administrateur requis');
        repondre(false, 'Alarme en cours : badge administrateur requis', ['alerte' => 1]);
    }

    $st = $pdo->prepare('SELECT * FROM utilisateurs WHERE uid_badge = ?');
    $st->execute([$uid]);
    $u = $st->fetch();
    if (!$u) $refuser('Badge inconnu');

    $userId = (int)$u['id'];
    $extra = ['nom' => $u['prenom'] . ' ' . $u['nom']];
    if (!$u['actif']) $refuser('Patient désactivé');

    // ---- Borne pharmacie : on affiche l'ordonnance sur l'écran relié à ce lecteur ----
    $lignes = lignes_disponibles($pdo, $userId);
    if (!$lignes) $refuser('Aucune ordonnance en cours');
    // Tout est bloqué (délai entre prises, contre-indication, rupture) -> refus avec la prochaine heure possible
    $prenables = array_filter($lignes, fn($l) => etat_ligne($l)['max'] > 0);
    if (!$prenables) {
        $enAttente = array_filter($lignes, fn($l) => etat_ligne($l)['prochaine']);
        if ($enAttente) {
            $noms = implode(', ', array_unique(array_column($enAttente, 'nom')));
            $prochaine = min(array_map(fn($l) => etat_ligne($l)['prochaine'], $enAttente));
            $refuser('Délai non écoulé : ' . $noms . ' (prochaine prise à ' . date('H:i', $prochaine) . ')');
        }
        $refuser('Aucun médicament disponible maintenant');
    }
    $pdo->prepare('REPLACE INTO borne_sessions (lecteur_id, utilisateur_id, uid_badge, expire) VALUES (?, ?, ?, NOW() + INTERVAL 3 MINUTE)')
        ->execute([$lecteurId, $userId, $uid]);
    $n = count($lignes);
    journaliser($pdo, $uid, $userId, $lecteurId, true, "Ordonnance affichée à l'écran ($n produit" . ($n > 1 ? 's' : '') . ')');
    repondre(true, "Ordonnance affichée à l'écran", $extra + ['produits' => $n]);
} catch (Throwable $ex) {
    error_log(basename(__FILE__) . ' : ' . $ex->getMessage());
    repondre(false, 'Erreur serveur (base de données)', [], 500);
}
