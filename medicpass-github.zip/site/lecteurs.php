<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
check_csrf();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    try {
        if ($action === 'enregistrer') {
            $nom = trim($_POST['nom'] ?? '');
            $empl = trim($_POST['emplacement'] ?? '');
            if ($nom === '') {
                flash('erreur', 'Le nom du lecteur est obligatoire.');
            } elseif ($id > 0) {
                $pdo->prepare("UPDATE lecteurs SET nom = ?, emplacement = ?, type = 'pharmacie' WHERE id = ?")->execute([$nom, $empl, $id]);
                flash('succes', "Lecteur $nom modifié.");
            } else {
                $pdo->prepare('INSERT INTO lecteurs (nom, emplacement, type, cle_api) VALUES (?, ?, ?, ?)')
                    ->execute([$nom, $empl, 'pharmacie', bin2hex(random_bytes(16))]);
                flash('succes', "Lecteur $nom créé. Copiez son numéro et sa clé dans le programme de la carte.");
            }
        } elseif ($action === 'regenerer') {
            $pdo->prepare('UPDATE lecteurs SET cle_api = ? WHERE id = ?')->execute([bin2hex(random_bytes(16)), $id]);
            flash('succes', 'Nouvelle clé générée. Mettez-la à jour dans le programme de la carte.');
        } elseif ($action === 'basculer') {
            $pdo->prepare('UPDATE lecteurs SET actif = 1 - actif WHERE id = ?')->execute([$id]);
            flash('succes', 'Statut du lecteur modifié.');
        } elseif ($action === 'supprimer') {
            $pdo->prepare('DELETE FROM lecteurs WHERE id = ?')->execute([$id]);
            flash('succes', 'Lecteur supprimé.');
        }
    } catch (PDOException $ex) {
        flash('erreur', 'Erreur de base de données : ' . $ex->getMessage());
    }
    redirect('lecteurs.php');
}

$edit = null;
if (isset($_GET['edit'])) {
    $st = $pdo->prepare('SELECT * FROM lecteurs WHERE id = ?');
    $st->execute([(int)$_GET['edit']]);
    $edit = $st->fetch() ?: null;
}
$lecteurs = $pdo->query('SELECT * FROM lecteurs ORDER BY id')->fetchAll();

$title = 'Lecteurs';
$page = 'lecteurs';
require __DIR__ . '/includes/header.php';
?>
<section class="panneau">
  <div class="panneau-tete"><h2><?= $edit ? 'Modifier ' . e($edit['nom']) : 'Nouveau lecteur' ?></h2></div>
  <p class="muted">Chaque carte NodeMCU est un lecteur de pharmacie : quand un patient badge, ses médicaments prescrits s'affichent sur l'écran pharmacie relié à ce lecteur.</p>
  <form method="post" class="formulaire">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="enregistrer">
    <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
    <div class="ligne2">
      <label>Nom<input name="nom" value="<?= e($edit['nom'] ?? '') ?>" required placeholder="Pharmacie – comptoir 1"></label>
      <label>Emplacement<input name="emplacement" value="<?= e($edit['emplacement'] ?? '') ?>" placeholder="Bâtiment A, RDC"></label>
    </div>
    <div class="actions">
      <button class="btn btn-primaire"><?= $edit ? 'Enregistrer les modifications' : 'Créer le lecteur' ?></button>
      <?php if ($edit): ?><a class="btn" href="lecteurs.php">Annuler</a><?php endif; ?>
    </div>
  </form>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2>Parc de lecteurs (<?= count($lecteurs) ?>)</h2></div>
  <?php if (!$lecteurs): ?>
    <p class="vide">Aucun lecteur. Créez-en un pour obtenir le numéro et la clé à mettre dans la carte.</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>N°</th><th>Nom</th><th>À copier dans la carte</th><th>Dernier badge</th><th>Statut</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($lecteurs as $l): ?>
      <tr>
        <td class="mono"><strong><?= (int)$l['id'] ?></strong></td>
        <td><?= e($l['nom']) ?><?= $l['emplacement'] ? '<br><span class="muted">' . e($l['emplacement']) . '</span>' : '' ?></td>
        <td><code class="config">LECTEUR_ID = <?= (int)$l['id'] ?>;<br>CLE_API = "<?= e($l['cle_api']) ?>";</code></td>
        <td class="nowrap mono"><?= e(date_fr($l['derniere_activite'], true, false)) ?></td>
        <td><?= $l['actif'] ? '<span class="tag ok">Actif</span>' : '<span class="tag neutre">Désactivé</span>' ?></td>
        <td class="actions">
          <a class="btn btn-sm btn-primaire" href="borne.php?lecteur=<?= (int)$l['id'] ?>">Ouvrir l'écran</a>
          <a class="btn btn-sm" href="lecteurs.php?edit=<?= (int)$l['id'] ?>">Modifier</a>
          <?= action_btn('basculer', (int)$l['id'], $l['actif'] ? 'Désactiver' : 'Activer') ?>
          <?= action_btn('regenerer', (int)$l['id'], 'Nouvelle clé', '', "L'ancienne clé ne marchera plus. Continuer ?") ?>
          <?= action_btn('supprimer', (int)$l['id'], 'Supprimer', 'btn-danger', 'Supprimer le lecteur ' . $l['nom'] . ' ?') ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
