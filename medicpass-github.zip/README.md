# Medic Pass

Délivrance de médicaments sur ordonnance par badge RFID.
Projet réalisé dans le cadre du workshop IoT — B3 SysOps 2026-2027, EPSI Montpellier — **Groupe 8**.

Un médecin prescrit une ordonnance. Le patient passe son badge sur un lecteur en pharmacie.
Un écran, face à lui, affiche uniquement les médicaments auxquels il a droit à cet instant ;
il choisit ce qu'il retire, et le stock ainsi que son ordonnance sont mis à jour automatiquement.

---

## Architecture

```
Badge RFID → PN532 (I2C) → NodeMCU ESP8266 → Wi-Fi → API PHP → MariaDB
                                                        ↑
                        Site web (administration / médecin / écran pharmacie)
```

La carte ne se connecte jamais directement à la base : elle passe toujours par l'API,
et ne connaît que la clé secrète de son propre lecteur.

## Contenu du dépôt

| Dossier | Contenu |
|---|---|
| `site/` | Application web PHP : API, administration, espace médecin, écran pharmacie |
| `carte/` | Programme du lecteur (C++ Arduino / PlatformIO) et sa documentation |

## Fonctionnalités

- **Ordonnances** : quantités prescrites et délivrées, posologie, date de validité, statut.
- **Écran pharmacie** : page d'accueil verrouillée, identification par badge, choix des quantités, session de 3 minutes.
- **Garde-fous médicaux** : délai minimal entre deux prises, contre-indications liées aux conditions du patient, contrôle du stock.
- **Connexion par badge** : un badge par compte ; un badge administrateur ou médecin ouvre la session de son propriétaire directement depuis l'écran pharmacie.
- **Trois profils** : administrateur (accès complet), médecin (ordonnances et patients), pharmacien (écran pharmacie).
- **Anti-abus** : au bout de plusieurs refus consécutifs d'un même badge, une sirène se déclenche ; seul un badge administrateur l'arrête.
- **Journal et statistiques** : tous les passages sont journalisés, avec mise à jour en direct, export CSV et graphiques.
- **Paramètres** : volume et sons du buzzer réglables à distance (suites de notes), test à distance sur un lecteur.

## Installation du site

### Prérequis

- PHP 8.1 ou plus, avec l'extension `pdo_mysql`
- Nginx ou Apache
- MariaDB 10.4 ou plus (ou MySQL 8)

### Étapes

1. Copier le contenu de `site/` dans le dossier web du serveur.
2. Dupliquer `config.exemple.php` en `config.php`, puis y renseigner les identifiants de la base.
3. Ouvrir `install.php` dans un navigateur et créer le premier compte administrateur.
4. **Supprimer `install.php`** du serveur.
5. Dans **Lecteurs**, créer un lecteur : son numéro et sa clé sont à recopier dans le programme de la carte.
6. Dans **Comptes**, associer un badge aux comptes administrateur et médecin.

Le schéma de la base est créé à l'installation, puis mis à jour automatiquement au premier
chargement d'une page après une mise à jour du code.

### Note de sécurité

`config.php` contient le mot de passe de la base : il est exclu du dépôt par `.gitignore`
et ne doit jamais être publié.

## Installation de la carte

Voir [`carte/README.md`](carte/README.md) : câblage, bibliothèque PN532 et paramètres à renseigner.

## API

| Point d'entrée | Appelé par | Rôle |
|---|---|---|
| `api/badge.php` | Lecteur | Décide si le badge est accepté ou refusé, journalise le passage |
| `api/reglages.php` | Lecteur (toutes les 3 s) | Volume, sons, tests, état de l'alarme |
| `borne_api.php` | Écran pharmacie | Patient identifié, droits, validation d'une délivrance |
| `logs_flux.php` | Administration | Nouvelles lignes du journal (mise à jour en direct) |

Exemple de requête envoyée par un lecteur :

```
POST /api/badge.php
uid=91:A4:31:07&lecteur=1&cle=<clé du lecteur>
```

```json
{"autorise": true, "message": "Ordonnance affichée à l'écran", "nom": "Mathis Nav", "produits": 2}
```

## Modèle de données

`admins`, `utilisateurs`, `medicaments`, `conditions`, `patient_conditions`,
`medicament_contre_indications`, `ordonnances`, `ordonnance_lignes`, `delivrances`,
`lecteurs`, `logs`, `borne_sessions`, `parametres`.

Le schéma complet est défini dans [`site/includes/schema.php`](site/includes/schema.php).

## Sécurité

- Mots de passe hachés (`password_hash`), jeton anti-CSRF sur tous les formulaires.
- Requêtes SQL exclusivement préparées.
- Contrôle du profil sur chaque page et sur chaque point d'entrée de l'API.
- Une clé secrète par lecteur, régénérable depuis l'administration.
- Aucun identifiant de base de données dans le programme de la carte.

## Matériel

NodeMCU ESP8266 · module PN532 · badges RFID ISO 14443A · 2 LED (verte, rouge) avec résistances ·
buzzer passif · plaque d'essai.
