#include <Arduino.h>
#include <Wire.h>
#include <PN532_I2C.h>
#include <PN532.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClientSecure.h>

// ================= A MODIFIER =================
const char* WIFI_SSID  = "NomDuWifi";
const char* WIFI_PASS  = "MotDePasseWifi";
const char* API_URL    = "http://IP_DU_SERVEUR:PORT/api/badge.php";
const int   LECTEUR_ID = 1;
const char* CLE_API    = "cle_affichee_dans_la_page_lecteurs";
// ==============================================
// Le volume et tous les sons se reglent sur le site : Parametres (admin).

// Cablage PN532 : SDA (blanc) -> D2, SCL (gris) -> D1, VCC -> 3V, GND -> G
// Interrupteur PN532 : 1 sur ON, 2 pas sur ON (mode I2C)
// LED verte : D5 -> resistance -> + de la LED, - de la LED -> G
// LED rouge : D8 -> resistance -> + de la LED, - de la LED -> G
// Buzzer    : S -> D7, milieu -> 3V, - -> G
const int LED_VERTE = D5;
const int LED_ROUGE = D8;
const int BUZZER    = D7;

// Reglages du son (valeurs par defaut, remplacees par celles du site)
// Un son = suite de notes "frequence:duree" (Hz:ms), 0 Hz = silence
int    volume        = 30;   // 0 = muet, 100 = maximum
String motifValide    = "1500:1000";
String motifRefus     = "300:1000";
String motifErreur    = "300:120 0:120 300:120 0:120 300:120";
String motifDemarrage = "1500:200 0:150 300:200";
const int LED_AUTO = -1;     // demarrage : verte pour les notes aigues, rouge pour les graves

unsigned long dernierReglage = 0;
const unsigned long INTERVALLE_REGLAGES = 3000;  // le lecteur demande ses reglages toutes les 3 s

// Easter egg : sirene d'alerte declenchee depuis le site (Parametres)
bool alerte = false;
bool alerteVerrouillee = false;   // alarme anti-abus : seul le badge admin l'arrete (pas d'arret automatique)
unsigned long debutAlerte = 0;

PN532_I2C pn532i2c(Wire);
PN532 nfc(pn532i2c);

// ---------- Son et LED ----------
void son(int frequence) {
  if (volume <= 0) return;
  analogWriteRange(1000);
  analogWriteFreq(frequence);
  analogWrite(BUZZER, volume * volume / 20);   // 100 -> 500/1000 (maximum), 30 -> 45, 10 -> 5
}

void silence() {
  analogWrite(BUZZER, 0);
  digitalWrite(BUZZER, LOW);
}

void clignoter(int led, int fois, int duree) {
  for (int i = 0; i < fois; i++) {
    digitalWrite(led, HIGH);
    delay(duree);
    digitalWrite(led, LOW);
    delay(duree);
  }
}

// Joue un son (suite de notes) en allumant la LED pendant les notes
void jouer(const String& motif, int led) {
  int n = motif.length();
  int i = 0, notes = 0, total = 0;
  while (i < n && notes < 16 && total < 6000) {
    while (i < n && !isDigit(motif[i])) i++;          // saute espaces et virgules
    int deuxPoints = motif.indexOf(':', i);
    if (i >= n || deuxPoints < 0) break;
    int j = deuxPoints + 1;
    while (j < n && isDigit(motif[j])) j++;
    int frequence = motif.substring(i, deuxPoints).toInt();
    int duree = constrain(motif.substring(deuxPoints + 1, j).toInt(), 0, 3000);
    i = j;
    if (duree <= 0) continue;

    if (frequence > 0) {
      int l = (led == LED_AUTO) ? (frequence >= 800 ? LED_VERTE : LED_ROUGE) : led;
      digitalWrite(l, HIGH);
      son(constrain(frequence, 100, 5000));
    }
    delay(duree);
    silence();
    digitalWrite(LED_VERTE, LOW);
    digitalWrite(LED_ROUGE, LOW);
    notes++;
    total += duree;
  }
}

// Sirene facon alerte nucleaire : monte et descend lentement, LED rouge qui clignote
void sirene() {
  unsigned long t = (millis() - debutAlerte) % 4000;              // un cycle toutes les 4 secondes
  float p = (t < 2000) ? t / 2000.0 : (4000 - t) / 2000.0;         // 0 -> 1 -> 0
  son(350 + (int)(750 * p));                                       // 350 Hz -> 1100 Hz -> 350 Hz
  digitalWrite(LED_ROUGE, ((millis() - debutAlerte) / 300) % 2 ? HIGH : LOW);
}

void arreterAlerte() {
  alerte = false;
  silence();
  digitalWrite(LED_VERTE, LOW);
  digitalWrite(LED_ROUGE, LOW);
}

// ---------- Reseau ----------
void connecterWifi() {
  if (WiFi.status() == WL_CONNECTED) return;
  Serial.printf("Connexion au Wi-Fi \"%s\"", WIFI_SSID);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  unsigned long debut = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - debut < 20000) {
    delay(500);
    Serial.print(".");
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.printf("\nWi-Fi connecte, adresse IP : %s\n", WiFi.localIP().toString().c_str());
  } else {
    Serial.println("\nEchec Wi-Fi : verifier le nom et le mot de passe");
  }
}

// Envoie une requete POST, renvoie le code HTTP (negatif si le serveur est injoignable)
int envoyerPost(const String& url, const String& corps, String& reponse, uint16_t timeoutMs) {
  WiFiClient clientHttp;
  BearSSL::WiFiClientSecure clientHttps;
  clientHttps.setInsecure();

  HTTPClient http;
  if (url.startsWith("https")) http.begin(clientHttps, url);
  else                         http.begin(clientHttp, url);
  http.setTimeout(timeoutMs);
  http.addHeader("Content-Type", "application/x-www-form-urlencoded");

  int code = http.POST(corps);
  if (code > 0) reponse = http.getString();
  else          reponse = http.errorToString(code);
  http.end();
  return code;
}

// Lit un nombre dans la reponse JSON du serveur, ex. "volume":30
int lireEntier(const String& json, const char* cle, int defaut) {
  String motif = String("\"") + cle + "\":";
  int i = json.indexOf(motif);
  if (i < 0) return defaut;
  return json.substring(i + motif.length()).toInt();
}

// Lit un texte dans la reponse JSON du serveur, ex. "valide":"1500:1000"
String lireTexte(const String& json, const char* cle, const String& defaut) {
  String motif = String("\"") + cle + "\":\"";
  int i = json.indexOf(motif);
  if (i < 0) return defaut;
  int debut = i + motif.length();
  int fin = json.indexOf('"', debut);
  if (fin < 0) return defaut;
  String valeur = json.substring(debut, fin);
  return valeur.length() ? valeur : defaut;
}

String urlReglages() {
  String u = API_URL;
  u.replace("badge.php", "reglages.php");
  return u;
}

// Recupere le volume et les sons depuis le site, et joue un son si l'admin a demande un test
void chargerReglages() {
  if (WiFi.status() != WL_CONNECTED) return;
  String rep;
  int code = envoyerPost(urlReglages(), "lecteur=" + String(LECTEUR_ID) + "&cle=" + CLE_API, rep, 2000);
  if (code != 200) return;

  int    v  = constrain(lireEntier(rep, "volume", volume), 0, 100);
  String mv = lireTexte(rep, "valide", motifValide);
  String mr = lireTexte(rep, "refus", motifRefus);
  String me = lireTexte(rep, "erreur", motifErreur);
  String md = lireTexte(rep, "demarrage", motifDemarrage);
  if (v != volume || mv != motifValide || mr != motifRefus || me != motifErreur || md != motifDemarrage) {
    volume = v; motifValide = mv; motifRefus = mr; motifErreur = me; motifDemarrage = md;
    Serial.printf("Reglages du son : volume %d | valide %s | refus %s | erreur %s | demarrage %s\n",
                  volume, motifValide.c_str(), motifRefus.c_str(), motifErreur.c_str(), motifDemarrage.c_str());
  }

  bool demandeAlerte = lireEntier(rep, "alerte", 0) == 1;
  alerteVerrouillee = lireEntier(rep, "verrou", 0) == 1;
  if (demandeAlerte && !alerte) {
    Serial.println(alerteVerrouillee ? "!!! ALERTE ANTI-ABUS : badge administrateur requis !!!" : "!!! ALERTE DECLENCHEE DEPUIS LE SITE !!!");
    alerte = true;
    debutAlerte = millis();
  } else if (!demandeAlerte && alerte) {
    Serial.println("Alerte levee");
    arreterAlerte();
  }
  if (alerte) return;   // pas de test de son pendant l'alerte

  String test = lireTexte(rep, "test", "");
  if (test.length()) Serial.println("Test demande depuis le site : " + test);
  if (test == "valide")         jouer(motifValide, LED_VERTE);
  else if (test == "refus")     jouer(motifRefus, LED_ROUGE);
  else if (test == "erreur")    jouer(motifErreur, LED_ROUGE);
  else if (test == "demarrage") jouer(motifDemarrage, LED_AUTO);
}

void envoyerBadge(const String& uid) {
  connecterWifi();
  if (WiFi.status() != WL_CONNECTED) {
    jouer(motifErreur, LED_ROUGE);
    return;
  }

  String reponse;
  int code = envoyerPost(API_URL, "uid=" + uid + "&lecteur=" + String(LECTEUR_ID) + "&cle=" + CLE_API, reponse, 5000);

  if (code > 0) {
    Serial.printf("Serveur (%d) : %s\n", code, reponse.c_str());
    if (reponse.indexOf("\"alerte\":1") >= 0) {
      Serial.println(">>> ALARME : badge administrateur requis");
      if (!alerte) { alerte = true; alerteVerrouillee = true; debutAlerte = millis(); }
    } else if (reponse.indexOf("\"autorise\":true") >= 0) {
      Serial.println(">>> AUTORISE");
      jouer(motifValide, LED_VERTE);   // vert + son "valide"
    } else {
      Serial.println(">>> REFUSE");
      jouer(motifRefus, LED_ROUGE);    // rouge + son "refuse"
    }
  } else {
    Serial.printf("Serveur injoignable : %s\n", reponse.c_str());
    jouer(motifErreur, LED_ROUGE);
  }
}

// ---------- Programme principal ----------
void setup() {
  Serial.begin(115200);
  pinMode(LED_VERTE, OUTPUT);
  pinMode(LED_ROUGE, OUTPUT);
  pinMode(BUZZER, OUTPUT);
  digitalWrite(LED_VERTE, LOW);
  digitalWrite(LED_ROUGE, LOW);
  silence();
  delay(1000);
  Serial.println("\nDemarrage du lecteur RFID...");

  nfc.begin();
  uint32_t version = 0;
  for (int i = 1; i <= 5 && !version; i++) {
    version = nfc.getFirmwareVersion();
    if (!version) delay(500);
  }
  if (!version) {
    Serial.println("PN532 introuvable : debrancher l'USB 10 secondes puis rebrancher");
    while (true) { clignoter(LED_ROUGE, 1, 300); }
  }
  Serial.printf("PN532 detecte - firmware %d.%d\n", (version >> 16) & 0xFF, (version >> 8) & 0xFF);
  nfc.SAMConfig();
  nfc.setPassiveActivationRetries(0x10);

  connecterWifi();
  chargerReglages();

  // Son de demarrage (reglable sur le site)
  jouer(motifDemarrage, LED_AUTO);

  Serial.println("Presentez un badge...");
}

void loop() {
  // Reglages et tests de son demandes depuis le site (toutes les secondes pendant une alerte)
  if (millis() - dernierReglage >= (alerte ? 1000UL : INTERVALLE_REGLAGES)) {
    dernierReglage = millis();
    chargerReglages();
  }

  // Pendant l'alerte : sirene en continu. On lit quand meme les badges : le badge admin l'arrete.
  // Arret de securite apres 5 minutes, sauf pour l'alarme anti-abus.
  if (alerte && !alerteVerrouillee && millis() - debutAlerte > 300000UL) arreterAlerte();
  if (alerte) sirene();

  uint8_t uid[7];
  uint8_t uidLength;

  if (nfc.readPassiveTargetID(PN532_MIFARE_ISO14443A, uid, &uidLength, alerte ? 60 : 500)) {
    String uidStr = "";
    for (uint8_t i = 0; i < uidLength; i++) {
      if (uid[i] < 0x10) uidStr += "0";
      uidStr += String(uid[i], HEX);
      if (i < uidLength - 1) uidStr += ":";
    }
    uidStr.toUpperCase();

    // Badge laisse pose sur le lecteur : on ne le renvoie pas plus d'une fois toutes les 2 secondes
    static String dernierUid = "";
    static unsigned long dernierEnvoi = 0;
    if (uidStr == dernierUid && millis() - dernierEnvoi < 2000) return;
    dernierUid = uidStr;
    dernierEnvoi = millis();

    Serial.println("Badge lu - UID : " + uidStr);
    envoyerBadge(uidStr);
    if (alerte) {
      dernierReglage = 0;   // relit tout de suite l'etat de l'alarme (arretee si c'etait le badge admin)
    } else {
      delay(500);
    }
  }
}
