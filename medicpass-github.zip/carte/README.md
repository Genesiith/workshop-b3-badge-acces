# Lecteur Medic Pass (NodeMCU ESP8266)

## Bibliothèque requise

Télécharger le dépôt [elechouse/PN532](https://github.com/elechouse/PN532) au format ZIP,
puis copier les dossiers `PN532` et `PN532_I2C` dans le dossier `lib/` du projet PlatformIO.

## Câblage

| Élément | Broche NodeMCU |
|---|---|
| PN532 — VCC | 3V |
| PN532 — GND | G |
| PN532 — SDA | D2 |
| PN532 — SCL | D1 |
| LED verte (+ via résistance) | D5 |
| LED rouge (+ via résistance) | D8 |
| Buzzer — S | D7 |
| Buzzer — alimentation | 3V |
| Buzzer — masse | G |

Interrupteur du PN532 : position 1 sur **ON**, position 2 hors ON (mode I2C).
Les cathodes (−) des LED vont à la masse (G).

## À renseigner dans `main.cpp`

```cpp
const char* WIFI_SSID  = "NomDuWifi";
const char* WIFI_PASS  = "MotDePasseWifi";
const char* API_URL    = "http://IP_DU_SERVEUR:PORT/api/badge.php";
const int   LECTEUR_ID = 1;            // numéro affiché dans Lecteurs
const char* CLE_API    = "cle_du_lecteur";
```

Le Wi-Fi doit être en **2,4 GHz** et sans portail d'authentification.
Le volume et les sons se règlent ensuite depuis le site, dans **Paramètres**.
