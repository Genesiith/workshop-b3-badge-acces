<?php
// =====================================================
//  CONFIGURATION DU SITE
//  Copier ce fichier en "config.php" puis remplir les valeurs.
//  config.php n'est jamais envoyé sur GitHub (voir .gitignore).
// =====================================================
if (!defined('APP')) exit;

define('DB_HOST', '127.0.0.1');
define('DB_PORT', 3306);
define('DB_NAME', 'rfid');
define('DB_USER', 'utilisateur');
define('DB_PASS', 'mot_de_passe');

define('APP_NAME', 'Medic Pass');
define('APP_TIMEZONE', 'Europe/Paris');
define('STOCK_ALERTE', 5);
