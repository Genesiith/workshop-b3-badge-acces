<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
$pdo = db();

$du = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['du'] ?? '') ? $_GET['du'] : '';
$au = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['au'] ?? '') ? $_GET['au'] : '';
$res = in_array($_GET['resultat'] ?? '', ['autorise', 'refuse'], true) ? $_GET['resultat'] : '';
$lect = (int)($_GET['lecteur'] ?? 0);
$q = trim($_GET['q'] ?? '');

$where = [];
$params = [];
if ($du !== '') { $where[] = 'l.date_heure >= ?'; $params[] = $du . ' 00:00:00'; }
if ($au !== '') { $where[] = 'l.date_heure <= ?'; $params[] = $au . ' 23:59:59'; }
if ($res !== '') { $where[] = 'l.resultat = ?'; $params[] = $res; }
if ($lect > 0) { $where[] = 'l.lecteur_id = ?'; $params[] = $lect; }
if ($q !== '') {
    $where[] = '(l.uid_badge LIKE ? OR u.nom LIKE ? OR u.prenom LIKE ? OR l.motif LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%");
}
$sqlWhere = $where ? ' WHERE ' . implode(' AND ', $where) : '';

// Export CSV (ouvrable dans Excel)
if (($_GET['export'] ?? '') === 'csv') {
    $st = $pdo->prepare(LOGS_SELECT . $sqlWhere . ' ORDER BY l.id DESC LIMIT 50000');
    $st->execute($params);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="journal-lectures-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Date', 'Badge', 'Patient', 'Lecteur', 'Médicament', 'Résultat', 'Motif'], ';', '"', '');
    while ($r = $st->fetch()) {
        fputcsv($out, [
            date_fr($r['date_heure']),
            $r['uid_badge'],
            $r['utilisateur_id'] ? $r['u_prenom'] . ' ' . $r['u_nom'] : 'Inconnu',
            $r['lecteur_nom'] ?? '',
            $r['med_nom'] ?? '',
            $r['resultat'] === 'autorise' ? 'Autorisé' : 'Refusé',
            $r['motif'],
        ], ';', '"', '');
    }
    exit;
}

$parPage = 50;
$st = $pdo->prepare('SELECT COUNT(*) FROM logs l LEFT JOIN utilisateurs u ON u.id = l.utilisateur_id' . $sqlWhere);
$st->execute($params);
$total = (int)$st->fetchColumn();
$pages = max(1, (int)ceil($total / $parPage));
$pageNum = min($pages, max(1, (int)($_GET['page'] ?? 1)));
$st = $pdo->prepare(LOGS_SELECT . $sqlWhere . ' ORDER BY l.id DESC LIMIT ' . $parPage . ' OFFSET ' . (($pageNum - 1) * $parPage));
$st->execute($params);
$rows = $st->fetchAll();
$lecteurs = $pdo->query('SELECT id, nom FROM lecteurs ORDER BY nom')->fetchAll();

function lien_page(int $n): string
{
    return 'logs.php?' . http_build_query(array_merge($_GET, ['page' => $n]));
}

$title = 'Journal';
$page = 'logs';
require __DIR__ . '/includes/header.php';
?>
<section class="panneau">
  <form method="get" class="filtres">
    <label>Du<input type="date" name="du" value="<?= e($du) ?>"></label>
    <label>Au<input type="date" name="au" value="<?= e($au) ?>"></label>
    <label>Résultat
      <select name="resultat">
        <option value="">Tous</option>
        <option value="autorise" <?= $res === 'autorise' ? 'selected' : '' ?>>Autorisés</option>
        <option value="refuse" <?= $res === 'refuse' ? 'selected' : '' ?>>Refusés</option>
      </select>
    </label>
    <label>Lecteur
      <select name="lecteur">
        <option value="0">Tous</option>
        <?php foreach ($lecteurs as $l): ?>
          <option value="<?= (int)$l['id'] ?>" <?= $lect === (int)$l['id'] ? 'selected' : '' ?>><?= e($l['nom']) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Recherche<input name="q" value="<?= e($q) ?>" placeholder="Nom, badge, motif"></label>
    <div class="actions">
      <button class="btn btn-primaire">Filtrer</button>
      <a class="btn" href="logs.php">Réinitialiser</a>
      <a class="btn" href="<?= e('logs.php?' . http_build_query(array_merge($_GET, ['export' => 'csv']))) ?>">Exporter en CSV</a>
    </div>
  </form>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2><?= $total ?> lecture<?= $total > 1 ? 's' : '' ?></h2><span class="muted">Page <?= $pageNum ?> sur <?= $pages ?></span></div>
  <?= logs_table($rows, $where ? 'Aucune lecture ne correspond à ces filtres.' : 'Aucune lecture enregistrée. Passez un badge sur un lecteur pour voir la première ligne apparaître ici.') ?>
  <?php if ($pages > 1): ?>
    <nav class="pagination">
      <?php if ($pageNum > 1): ?><a class="btn btn-sm" href="<?= e(lien_page($pageNum - 1)) ?>">Page précédente</a><?php endif; ?>
      <?php if ($pageNum < $pages): ?><a class="btn btn-sm" href="<?= e(lien_page($pageNum + 1)) ?>">Page suivante</a><?php endif; ?>
    </nav>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
