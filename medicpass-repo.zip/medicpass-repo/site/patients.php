<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
check_csrf();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    try {
        if ($action === 'ajouter') {
            $nom = trim($_POST['nom'] ?? '');
            $prenom = trim($_POST['prenom'] ?? '');
            $uid = normalize_uid($_POST['uid_badge'] ?? '');
            if ($nom === '' || $prenom === '') {
                flash('erreur', 'Le nom et le prénom sont obligatoires.');
            } else {
                $pdo->prepare('INSERT INTO utilisateurs (nom, prenom, uid_badge) VALUES (?, ?, ?)')
                    ->execute([$nom, $prenom, $uid !== '' ? $uid : null]);
                flash('succes', "$prenom $nom ajouté.");
                redirect('patient.php?id=' . (int)$pdo->lastInsertId());
            }
        } elseif ($action === 'basculer') {
            $pdo->prepare('UPDATE utilisateurs SET actif = 1 - actif WHERE id = ?')->execute([$id]);
            flash('succes', 'Statut du patient modifié.');
        } elseif ($action === 'supprimer') {
            $pdo->prepare('DELETE FROM utilisateurs WHERE id = ?')->execute([$id]);
            flash('succes', 'Patient supprimé, ainsi que ses ordonnances. Ses passages restent dans le journal.');
        }
    } catch (PDOException $ex) {
        flash('erreur', $ex->getCode() == 23000 ? 'Ce badge est déjà associé à un autre patient.' : 'Erreur de base de données : ' . $ex->getMessage());
    }
    redirect('patients.php');
}

$q = trim($_GET['q'] ?? '');
$sql = "SELECT u.*, (SELECT COUNT(*) FROM ordonnances o WHERE o.patient_id = u.id AND o.statut = 'active' AND o.date_expiration >= CURDATE()) AS ordos
    FROM utilisateurs u";
if ($q !== '') {
    $st = $pdo->prepare($sql . ' WHERE u.nom LIKE ? OR u.prenom LIKE ? OR u.uid_badge LIKE ? ORDER BY u.nom, u.prenom');
    $like = '%' . $q . '%';
    $st->execute([$like, $like, $like]);
    $patients = $st->fetchAll();
} else {
    $patients = $pdo->query($sql . ' ORDER BY u.nom, u.prenom')->fetchAll();
}

// Badges passés récemment mais associés à personne
$inconnus = $pdo->query("SELECT uid_badge, MAX(date_heure) AS vu FROM logs
    WHERE uid_badge NOT IN (SELECT uid_badge FROM utilisateurs WHERE uid_badge IS NOT NULL)
    GROUP BY uid_badge ORDER BY vu DESC LIMIT 8")->fetchAll();

$title = 'Patients';
$page = 'patients';
require __DIR__ . '/includes/header.php';
?>
<div class="grille">
  <section class="panneau">
    <div class="panneau-tete"><h2>Nouveau patient</h2></div>
    <form method="post" class="formulaire">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="ajouter">
      <div class="ligne2">
        <label>Prénom<input name="prenom" required></label>
        <label>Nom<input name="nom" required></label>
      </div>
      <label>Badge (UID)<input name="uid_badge" id="uid" placeholder="91:A4:31:07"></label>
      <button class="btn btn-primaire">Enregistrer le patient</button>
    </form>
  </section>

  <section class="panneau">
    <div class="panneau-tete"><h2>Badges inconnus récents</h2></div>
    <p class="muted">Passez un nouveau badge sur un lecteur : il apparaît ici. Cliquez dessus pour le mettre dans le formulaire. Les téléphones donnent un numéro différent à chaque passage : utilisez des badges physiques.</p>
    <?php if (!$inconnus): ?>
      <p class="vide">Aucun badge inconnu pour le moment.</p>
    <?php else: ?>
      <ul class="liste-badges">
        <?php foreach ($inconnus as $b): ?>
          <li><button type="button" class="btn btn-sm" onclick="document.getElementById('uid').value=<?= e(json_encode($b['uid_badge'])) ?>"><?= e($b['uid_badge']) ?></button>
          <span class="muted mono"><?= e(date_fr($b['vu'], true, false)) ?></span></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</div>

<section class="panneau">
  <div class="panneau-tete">
    <h2>Registre (<?= count($patients) ?>)</h2>
    <form method="get" class="recherche"><input name="q" value="<?= e($q) ?>" placeholder="Nom, prénom ou badge"><button class="btn btn-sm">Rechercher</button></form>
  </div>
  <?php if (!$patients): ?>
    <p class="vide"><?= $q !== '' ? 'Aucun patient ne correspond à cette recherche.' : 'Aucun patient. Ajoutez-en un avec le formulaire ci-dessus.' ?></p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Patient</th><th>Badge</th><th class="num">Ordonnances actives</th><th>Statut</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($patients as $u): ?>
      <tr>
        <td><a href="patient.php?id=<?= (int)$u['id'] ?>"><?= e($u['prenom'] . ' ' . $u['nom']) ?></a></td>
        <td><?= $u['uid_badge'] ? '<code>' . e($u['uid_badge']) . '</code>' : '<span class="muted">Aucun</span>' ?></td>
        <td class="num mono"><?= (int)$u['ordos'] ?></td>
        <td><?= $u['actif'] ? '<span class="tag ok">Actif</span>' : '<span class="tag neutre">Désactivé</span>' ?></td>
        <td class="actions">
          <a class="btn btn-sm" href="patient.php?id=<?= (int)$u['id'] ?>">Dossier</a>
          <?= action_btn('basculer', (int)$u['id'], $u['actif'] ? 'Désactiver' : 'Activer') ?>
          <?= action_btn('supprimer', (int)$u['id'], 'Supprimer', 'btn-danger', 'Supprimer ' . $u['prenom'] . ' ' . $u['nom'] . ' et ses ordonnances ?') ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
