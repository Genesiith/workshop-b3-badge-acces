<?php
define('APP', true);
require __DIR__ . '/../config.php';
date_default_timezone_set(APP_TIMEZONE);

if (!defined('NO_SESSION')) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

const ROLES = ['admin' => 'Administrateur', 'medecin' => 'Médecin', 'pharmacien' => 'Pharmacien'];

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $pdo->exec("SET time_zone = '" . date('P') . "'");
    }
    return $pdo;
}

function e($v): string
{
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}

function check_csrf(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !hash_equals(csrf_token(), (string)($_POST['csrf'] ?? ''))) {
        http_response_code(400);
        exit('Jeton de sécurité expiré. Revenez en arrière et rechargez la page.');
    }
}

function flash(string $type, string $msg): void
{
    $_SESSION['flash'][] = [$type, $msg];
}

function flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

// ---------- Paramètres (réglages du buzzer, commandes de test) ----------
const PARAMS_DEFAUT = ['volume' => '30', 'son_valide' => '1500', 'son_refus' => '300', 'duree_son' => '1000'];

// La table est créée automatiquement au premier usage (pas de mise à jour manuelle)
function parametres_table(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS parametres (
        cle VARCHAR(64) PRIMARY KEY,
        valeur VARCHAR(255) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function param_get(PDO $pdo, string $cle, ?string $defaut = null): ?string
{
    try {
        $st = $pdo->prepare('SELECT valeur FROM parametres WHERE cle = ?');
        $st->execute([$cle]);
        $v = $st->fetchColumn();
    } catch (PDOException $ex) {
        if ($ex->getCode() != '42S02') throw $ex;
        parametres_table($pdo);
        $v = false;
    }
    return $v === false ? ($defaut ?? (PARAMS_DEFAUT[$cle] ?? null)) : (string)$v;
}

function param_set(PDO $pdo, string $cle, string $valeur): void
{
    try {
        $pdo->prepare('REPLACE INTO parametres (cle, valeur) VALUES (?, ?)')->execute([$cle, $valeur]);
    } catch (PDOException $ex) {
        if ($ex->getCode() != '42S02') throw $ex;
        parametres_table($pdo);
        $pdo->prepare('REPLACE INTO parametres (cle, valeur) VALUES (?, ?)')->execute([$cle, $valeur]);
    }
}

// ---------- Sons du lecteur ----------
// Un son = une suite de notes "fréquence:durée" (Hz:ms), 0 Hz = silence. Ex. "1000:120 1500:120 2000:250"
const SONS = [
    'valide' => ['Badge validé', 'Joué avec la LED verte quand le patient est autorisé.', '1500:1000'],
    'refus' => ['Badge refusé', 'Joué avec la LED rouge quand le badge est refusé.', '300:1000'],
    'erreur' => ['Problème réseau', 'Wi-Fi coupé ou serveur injoignable.', '300:120 0:120 300:120 0:120 300:120'],
    'demarrage' => ['Démarrage', 'Joué quand la carte s\'allume (vert pour les notes aiguës, rouge pour les graves).', '1500:200 0:150 300:200'],
];
const SONS_MODELES = [
    'Bip court' => '1500:200',
    'Bip long' => '1500:1000',
    'Double bip' => '1500:150 0:100 1500:150',
    'Montée joyeuse' => '1000:120 1500:120 2000:250',
    'Descente' => '600:150 400:150 250:400',
    'Grave long' => '300:1000',
    'Alarme' => '300:120 0:120 300:120 0:120 300:120',
];

// Nettoie un motif : notes valides uniquement, 16 notes et 6 secondes maximum
function normaliser_motif(string $motif): string
{
    preg_match_all('/(\d+)\s*:\s*(\d+)/', $motif, $m, PREG_SET_ORDER);
    $notes = [];
    $total = 0;
    foreach ($m as $n) {
        $f = (int)$n[1];
        $d = max(20, min(3000, (int)$n[2]));
        $f = $f === 0 ? 0 : max(100, min(5000, $f));
        if (count($notes) >= 16 || $total + $d > 6000) break;
        $notes[] = "$f:$d";
        $total += $d;
    }
    return implode(' ', $notes);
}

// Motif enregistré, ou reprise des anciens réglages (fréquence + durée), ou son par défaut
function motif_son(PDO $pdo, string $type): string
{
    $motif = (string)param_get($pdo, 'motif_' . $type, '');
    if ($motif !== '') return $motif;
    if ($type === 'valide' || $type === 'refus') {
        $f = param_get($pdo, $type === 'valide' ? 'son_valide' : 'son_refus', '');
        $d = param_get($pdo, 'duree_son', '');
        if ($f !== '' && $d !== '' && ($f !== PARAMS_DEFAUT[$type === 'valide' ? 'son_valide' : 'son_refus'] || $d !== PARAMS_DEFAUT['duree_son'])) {
            return normaliser_motif("$f:$d");
        }
    }
    return SONS[$type][2];
}

// ---------- Comptes et rôles ----------
function role(): string
{
    return (string)($_SESSION['role'] ?? '');
}

function est_connecte(): bool
{
    return !empty($_SESSION['admin_id']) && isset(ROLES[role()]);
}

function page_accueil(string $r = ''): string
{
    $r = $r !== '' ? $r : role();
    if ($r === 'medecin') return 'ordonnances.php';
    if ($r === 'pharmacien') return 'borne.php';
    return 'index.php';
}

function require_login(): void
{
    if (!est_connecte()) {
        redirect('login.php');
    }
}

function require_role(string ...$roles): void
{
    require_login();
    if (!in_array(role(), $roles, true)) {
        flash('erreur', 'Accès réservé à un autre profil.');
        redirect(page_accueil());
    }
}

// "91a43107" ou "91 A4 31 07" -> "91:A4:31:07" (même format que le lecteur)
function normalize_uid(string $uid): string
{
    $hex = strtoupper((string)preg_replace('/[^0-9a-fA-F]/', '', $uid));
    return $hex === '' ? '' : implode(':', str_split($hex, 2));
}

function confirm_attr(string $msg): string
{
    return ' onsubmit="return confirm(' . e(json_encode($msg, JSON_UNESCAPED_UNICODE)) . ')"';
}

// Petit bouton d'action (formulaire POST protégé)
function action_btn(string $action, int $id, string $label, string $class = '', string $confirm = ''): string
{
    return '<form method="post" class="inline"' . ($confirm !== '' ? confirm_attr($confirm) : '') . '>'
        . csrf_field()
        . '<input type="hidden" name="action" value="' . e($action) . '">'
        . '<input type="hidden" name="id" value="' . $id . '">'
        . '<button type="submit" class="btn btn-sm ' . e($class) . '">' . e($label) . '</button></form>';
}

function date_fr(?string $dt, bool $heure = true, bool $secondes = true): string
{
    if (!$dt) return '—';
    if (!$heure) return date('d/m/Y', strtotime($dt));
    return date($secondes ? 'd/m/Y H:i:s' : 'd/m/Y H:i', strtotime($dt));
}

// ---------- Ordonnances ----------
// Lignes d'ordonnance encore à délivrer pour un patient (ordonnance active et non expirée),
// avec le délai entre deux prises et les contre-indications liées à ses conditions médicales
function lignes_disponibles(PDO $pdo, int $patientId): array
{
    $st = $pdo->prepare("SELECT l.id, l.ordonnance_id, l.quantite, l.delivre, (l.quantite - l.delivre) AS reste, l.posologie,
            m.id AS medicament_id, m.nom, m.description, m.stock, m.delai_minutes, o.date_expiration, a.identifiant AS medecin,
            (SELECT MAX(d.date_heure) FROM delivrances d WHERE d.patient_id = o.patient_id AND d.medicament_id = m.id) AS derniere_prise,
            (SELECT GROUP_CONCAT(c.nom ORDER BY c.nom SEPARATOR ', ')
               FROM medicament_contre_indications mc
               JOIN patient_conditions pc ON pc.condition_id = mc.condition_id AND pc.utilisateur_id = o.patient_id
               JOIN conditions c ON c.id = mc.condition_id
              WHERE mc.medicament_id = m.id) AS contre_indications
        FROM ordonnance_lignes l
        JOIN ordonnances o ON o.id = l.ordonnance_id
        JOIN medicaments m ON m.id = l.medicament_id
        LEFT JOIN admins a ON a.id = o.medecin_id
        WHERE o.patient_id = ? AND o.statut = 'active' AND o.date_expiration >= CURDATE()
          AND l.quantite > l.delivre AND m.actif = 1
        ORDER BY m.nom, o.date_expiration");
    $st->execute([$patientId]);
    return $st->fetchAll();
}

// "4 h", "30 min", "1 h 30"
function format_duree(int $minutes): string
{
    $h = intdiv($minutes, 60);
    $m = $minutes % 60;
    if ($h === 0) return $m . ' min';
    return $h . ' h' . ($m ? ' ' . str_pad((string)$m, 2, '0', STR_PAD_LEFT) : '');
}

// Ce que le patient peut prendre maintenant sur une ligne d'ordonnance
// -> ['max' => quantité possible, 'bloque' => raison ou null, 'prochaine' => timestamp ou null]
function etat_ligne(array $l): array
{
    if (!empty($l['contre_indications'])) {
        return ['max' => 0, 'bloque' => 'Contre-indiqué : ' . $l['contre_indications'], 'prochaine' => null];
    }
    $delai = (int)($l['delai_minutes'] ?? 0);
    if ($delai > 0 && !empty($l['derniere_prise'])) {
        $prochaine = strtotime($l['derniere_prise']) + $delai * 60;
        if ($prochaine > time()) {
            $attente = (int)ceil(($prochaine - time()) / 60);
            return ['max' => 0, 'bloque' => texte_attente($prochaine), 'prochaine' => $prochaine];
        }
    }
    if ((int)$l['stock'] <= 0) {
        return ['max' => 0, 'bloque' => 'Rupture de stock', 'prochaine' => null];
    }
    $max = min((int)$l['reste'], (int)$l['stock']);
    if ($delai > 0) $max = min($max, 1); // médicament avec délai : 1 prise à la fois
    return ['max' => $max, 'bloque' => null, 'prochaine' => null];
}

// "Vous devez encore attendre 3 h 12 avant d'en reprendre un (à 15:32)"
function texte_attente(int $prochaine, string $medicament = ''): string
{
    $attente = max(1, (int)ceil(($prochaine - time()) / 60));
    $quand = date('Y-m-d', $prochaine) === date('Y-m-d') ? 'à ' . date('H:i', $prochaine) : 'le ' . date('d/m à H:i', $prochaine);
    $quoi = $medicament !== '' ? 'de reprendre ' . $medicament : "d'en reprendre un";
    return 'Vous devez encore attendre ' . format_duree($attente) . ' avant ' . $quoi . ' (' . $quand . ')';
}

// "  enceinte " -> "Enceinte"
function normaliser_condition(string $nom): string
{
    $nom = trim((string)preg_replace('/\s+/u', ' ', $nom));
    if ($nom === '') return '';
    $premier = function_exists('mb_substr') ? mb_strtoupper(mb_substr($nom, 0, 1)) : strtoupper(substr($nom, 0, 1));
    $reste = function_exists('mb_substr') ? mb_substr($nom, 1) : substr($nom, 1);
    return couper($premier . $reste, 80);
}

// Conditions du patient qui interdisent ce médicament (tableau de noms)
function contre_indications(PDO $pdo, int $patientId, int $medId): array
{
    $st = $pdo->prepare('SELECT c.nom FROM medicament_contre_indications mc
        JOIN patient_conditions pc ON pc.condition_id = mc.condition_id AND pc.utilisateur_id = ?
        JOIN conditions c ON c.id = mc.condition_id
        WHERE mc.medicament_id = ? ORDER BY c.nom');
    $st->execute([$patientId, $medId]);
    return $st->fetchAll(PDO::FETCH_COLUMN);
}

function conditions_patient(PDO $pdo, int $patientId): array
{
    $st = $pdo->prepare('SELECT c.id, c.nom FROM patient_conditions pc JOIN conditions c ON c.id = pc.condition_id
        WHERE pc.utilisateur_id = ? ORDER BY c.nom');
    $st->execute([$patientId]);
    return $st->fetchAll();
}

function tag_ordonnance(array $o): string
{
    if ($o['statut'] === 'annulee') return '<span class="tag neutre">Annulée</span>';
    if ($o['statut'] === 'terminee') return '<span class="tag ok">Délivrée</span>';
    if ($o['date_expiration'] < date('Y-m-d')) return '<span class="tag alerte">Expirée</span>';
    return '<span class="tag info">Active</span>';
}

// ---------- Journal ----------
const LOGS_SELECT = "SELECT l.*, u.nom AS u_nom, u.prenom AS u_prenom, le.nom AS lecteur_nom, m.nom AS med_nom
    FROM logs l
    LEFT JOIN utilisateurs u ON u.id = l.utilisateur_id
    LEFT JOIN lecteurs le ON le.id = l.lecteur_id
    LEFT JOIN medicaments m ON m.id = l.medicament_id";

function logs_table(array $rows, string $vide = 'Aucune lecture enregistrée. Passez un badge sur un lecteur pour voir la première ligne apparaître ici.'): string
{
    if (!$rows) return '<p class="vide">' . e($vide) . '</p>';
    $lienPatient = role() === 'admin';
    $h = '<div class="table-wrap"><table class="journal"><thead><tr><th>Date</th><th>Badge</th><th>Patient</th><th>Lecteur</th><th>Médicament</th><th>Résultat</th><th>Motif</th></tr></thead><tbody>';
    foreach ($rows as $r) {
        $ok = $r['resultat'] === 'autorise';
        $nom = e($r['u_prenom'] . ' ' . $r['u_nom']);
        $user = $r['utilisateur_id']
            ? ($lienPatient ? '<a href="patient.php?id=' . (int)$r['utilisateur_id'] . '">' . $nom . '</a>' : $nom)
            : '<span class="muted">Inconnu</span>';
        $h .= '<tr class="' . ($ok ? 'ligne-ok' : 'ligne-ko') . '">'
            . '<td class="nowrap mono">' . e(date_fr($r['date_heure'])) . '</td>'
            . '<td><code>' . e($r['uid_badge']) . '</code></td>'
            . '<td>' . $user . '</td>'
            . '<td>' . e($r['lecteur_nom'] ?? '—') . '</td>'
            . '<td>' . e($r['med_nom'] ?? '—') . '</td>'
            . '<td>' . ($ok ? '<span class="tag ok">Autorisé</span>' : '<span class="tag ko">Refusé</span>') . '</td>'
            . '<td>' . e($r['motif']) . '</td></tr>';
    }
    return $h . '</tbody></table></div>';
}

// Coupe un texte sans casser les accents (mbstring pas toujours installé)
function couper(string $s, int $n): string
{
    return function_exists('mb_substr') ? mb_substr($s, 0, $n) : (string)preg_replace('/^(.{0,' . $n . '}).*$/us', '$1', $s);
}
