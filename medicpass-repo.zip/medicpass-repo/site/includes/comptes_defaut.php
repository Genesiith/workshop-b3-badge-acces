<?php
if (!defined('APP')) exit;

// Compte médecin demandé pour le projet (à changer ensuite dans "Mon compte")
function creer_compte_medecin(PDO $pdo): bool
{
    $st = $pdo->prepare('SELECT COUNT(*) FROM admins WHERE identifiant = ?');
    $st->execute(['Medecin']);
    if ((int)$st->fetchColumn() > 0) return false;
    $pdo->prepare("INSERT INTO admins (identifiant, mot_de_passe, role) VALUES ('Medecin', ?, 'medecin')")
        ->execute([password_hash('Medecin123', PASSWORD_DEFAULT)]);
    return true;
}
