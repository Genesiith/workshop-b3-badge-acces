<?php
// =====================================================
//  Réglages lus par les lecteurs toutes les 3 secondes
//  POST lecteur=3&cle=xxxxxxxx
//  Réponse : {"volume":30,"valide":"1500:1000","refus":"300:1000","erreur":"...","demarrage":"...","test":""}
//  Chaque son est une suite de notes "fréquence:durée" (0 Hz = silence).
//  "test" vaut le nom d'un son quand un admin demande de le faire jouer.
// =====================================================
define('NO_SESSION', true);
require __DIR__ . '/../includes/init.php';
header('Content-Type: application/json; charset=utf-8');

function sortie(array $d, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($d, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$lecteurId = (int)($_POST['lecteur'] ?? 0);
$cle = (string)($_POST['cle'] ?? '');
if ($lecteurId <= 0 || $cle === '') sortie(['erreur' => 'Paramètres manquants (lecteur, cle)'], 400);

try {
    $pdo = db();
    $st = $pdo->prepare('SELECT cle_api FROM lecteurs WHERE id = ?');
    $st->execute([$lecteurId]);
    $cleOk = $st->fetchColumn();
    if (!$cleOk || !hash_equals((string)$cleOk, $cle)) sortie(['erreur' => 'Lecteur non reconnu'], 401);

    param_set($pdo, 'vu_' . $lecteurId, (string)time());

    // Commande de test en attente (ignorée si plus vieille qu'une minute)
    $test = '';
    $cmd = (string)param_get($pdo, 'test_' . $lecteurId, '');
    if ($cmd !== '') {
        [$type, $quand] = array_pad(explode('|', $cmd), 2, '0');
        if (isset(SONS[$type]) && time() - (int)$quand <= 60) $test = $type;
        param_set($pdo, 'test_' . $lecteurId, '');
    }

    $rep = ['volume' => (int)param_get($pdo, 'volume')];
    foreach (array_keys(SONS) as $type) $rep[$type] = motif_son($pdo, $type);
    $rep['test'] = $test;
    $alerte = (int)param_get($pdo, 'alerte_' . $lecteurId, '0');
    $rep['alerte'] = ($alerte && time() - $alerte <= 300) ? 1 : 0;
    sortie($rep);
} catch (PDOException $ex) {
    sortie(['erreur' => 'Erreur serveur (base de données)'], 500);
}
