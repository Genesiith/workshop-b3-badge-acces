<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
check_csrf();
$pdo = db();

$id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT * FROM utilisateurs WHERE id = ?');
$st->execute([$id]);
$u = $st->fetch();
if (!$u) {
    flash('erreur', 'Patient introuvable.');
    redirect('patients.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'infos') {
            $nom = trim($_POST['nom'] ?? '');
            $prenom = trim($_POST['prenom'] ?? '');
            $uid = normalize_uid($_POST['uid_badge'] ?? '');
            if ($nom === '' || $prenom === '') {
                flash('erreur', 'Le nom et le prénom sont obligatoires.');
            } else {
                $pdo->prepare('UPDATE utilisateurs SET nom = ?, prenom = ?, uid_badge = ?, actif = ? WHERE id = ?')
                    ->execute([$nom, $prenom, $uid !== '' ? $uid : null, isset($_POST['actif']) ? 1 : 0, $id]);
                flash('succes', 'Dossier enregistré.');
            }
        } elseif ($action === 'ajouter_condition') {
            $nom = normaliser_condition((string)($_POST['condition'] ?? ''));
            if ($nom === '') {
                flash('erreur', 'Indiquez une condition, par exemple « Enceinte » ou « Diabétique ».');
            } else {
                // La condition est créée une seule fois dans la base, puis réutilisée
                $pdo->prepare('INSERT IGNORE INTO conditions (nom) VALUES (?)')->execute([$nom]);
                $st = $pdo->prepare('SELECT id, nom FROM conditions WHERE nom = ?');
                $st->execute([$nom]);
                $c = $st->fetch();
                $pdo->prepare('INSERT IGNORE INTO patient_conditions (utilisateur_id, condition_id) VALUES (?, ?)')->execute([$id, $c['id']]);
                flash('succes', 'Condition « ' . $c['nom'] . ' » ajoutée au dossier.');
            }
        } elseif ($action === 'retirer_condition') {
            $pdo->prepare('DELETE FROM patient_conditions WHERE utilisateur_id = ? AND condition_id = ?')->execute([$id, (int)($_POST['condition_id'] ?? 0)]);
            flash('succes', 'Condition retirée du dossier.');
        }
    } catch (PDOException $ex) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('erreur', $ex->getCode() == 23000 ? 'Ce badge est déjà associé à un autre patient.' : 'Erreur de base de données : ' . $ex->getMessage());
    }
    redirect('patient.php?id=' . $id);
}

$st = $pdo->prepare("SELECT o.*, a.identifiant AS medecin,
        (SELECT GROUP_CONCAT(CONCAT(m.nom, ' ', l.delivre, '/', l.quantite) SEPARATOR ' · ')
           FROM ordonnance_lignes l JOIN medicaments m ON m.id = l.medicament_id WHERE l.ordonnance_id = o.id) AS resume
    FROM ordonnances o LEFT JOIN admins a ON a.id = o.medecin_id
    WHERE o.patient_id = ? ORDER BY o.id DESC");
$st->execute([$id]);
$ordos = $st->fetchAll();
$droits = lignes_disponibles($pdo, $id);
$conditions = conditions_patient($pdo, $id);
$toutesConditions = $pdo->query('SELECT nom FROM conditions ORDER BY nom')->fetchAll(PDO::FETCH_COLUMN);
$st = $pdo->prepare(LOGS_SELECT . ' WHERE l.utilisateur_id = ? ORDER BY l.id DESC LIMIT 15');
$st->execute([$id]);
$historique = $st->fetchAll();

$title = $u['prenom'] . ' ' . $u['nom'];
$page = 'patients';
require __DIR__ . '/includes/header.php';
?>
<p><a href="patients.php">Retour au registre</a></p>
<div class="grille">
  <section class="panneau">
    <div class="panneau-tete"><h2>Identité</h2></div>
    <form method="post" class="formulaire">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="infos">
      <div class="ligne2">
        <label>Prénom<input name="prenom" value="<?= e($u['prenom']) ?>" required></label>
        <label>Nom<input name="nom" value="<?= e($u['nom']) ?>" required></label>
      </div>
      <label>Badge (UID)<input name="uid_badge" value="<?= e($u['uid_badge']) ?>" placeholder="Aucun badge associé"></label>
      <label class="case"><input type="checkbox" name="actif" <?= $u['actif'] ? 'checked' : '' ?>> Dossier actif (décoché : son badge est refusé partout)</label>
      <button class="btn btn-primaire">Enregistrer</button>
    </form>
  </section>

<section class="panneau">
  <div class="panneau-tete"><h2>Conditions médicales</h2><span class="muted">Utilisées pour bloquer les médicaments contre-indiqués</span></div>
  <?php if (!$conditions): ?>
    <p class="vide">Aucune condition renseignée.</p>
  <?php else: ?>
    <div class="etiquettes">
      <?php foreach ($conditions as $c): ?>
        <form method="post" class="etiquette"<?= confirm_attr('Retirer « ' . $c['nom'] . ' » du dossier ?') ?>>
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="retirer_condition">
          <input type="hidden" name="condition_id" value="<?= (int)$c['id'] ?>">
          <span><?= e($c['nom']) ?></span>
          <button type="submit" aria-label="Retirer <?= e($c['nom']) ?>">×</button>
        </form>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
  <form method="post" class="recherche mt">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="ajouter_condition">
    <input name="condition" list="liste-conditions" required maxlength="80" placeholder="Enceinte, Diabétique, Allergie pénicilline…" aria-label="Nouvelle condition">
    <datalist id="liste-conditions">
      <?php foreach ($toutesConditions as $nomC): ?><option value="<?= e($nomC) ?>"><?php endforeach; ?>
    </datalist>
    <button class="btn btn-sm btn-primaire">Ajouter</button>
  </form>
</section>
</div>

<section class="panneau">
  <div class="panneau-tete"><h2>Droits en pharmacie</h2><span class="muted">Ce que l'écran pharmacie affichera à son prochain passage</span></div>
  <?php if (!$droits): ?>
    <p class="vide">Aucun produit à délivrer : pas d'ordonnance active.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Médicament</th><th>Posologie</th><th class="num">Reste à délivrer</th><th>Valable jusqu'au</th><th>Maintenant</th></tr></thead>
      <tbody>
      <?php foreach ($droits as $d): $et = etat_ligne($d); ?>
        <tr><td><?= e($d['nom']) ?></td><td><?= e($d['posologie']) ?></td><td class="num mono"><?= (int)$d['reste'] ?></td><td class="mono"><?= e(date_fr($d['date_expiration'], false)) ?></td>
          <td><?= $et['bloque'] ? '<span class="tag ' . (str_starts_with($et['bloque'], 'Contre') ? 'ko' : 'alerte') . '">' . e($et['bloque']) . '</span>' : '<span class="tag ok">Disponible</span>' ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2>Ordonnances</h2><a class="btn btn-sm btn-primaire" href="ordonnances.php?patient=<?= $id ?>#nouvelle">Nouvelle ordonnance</a></div>
  <?php if (!$ordos): ?>
    <p class="vide">Aucune ordonnance pour ce patient.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>N°</th><th>Prescrite le</th><th>Par</th><th>Produits (délivrés / prescrits)</th><th>Statut</th></tr></thead>
      <tbody>
      <?php foreach ($ordos as $o): ?>
        <tr>
          <td><a href="ordonnance.php?id=<?= (int)$o['id'] ?>" class="mono">#<?= (int)$o['id'] ?></a></td>
          <td class="mono"><?= e(date_fr($o['cree_le'], false)) ?></td>
          <td><?= e($o['medecin'] ?? '—') ?></td>
          <td><?= e($o['resume']) ?></td>
          <td><?= tag_ordonnance($o) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2>Derniers passages</h2><?php if ($u['uid_badge']): ?><a href="logs.php?q=<?= urlencode($u['uid_badge']) ?>">Tout son historique</a><?php endif; ?></div>
  <?= logs_table($historique, 'Aucun passage pour ce patient.') ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
