<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
check_csrf();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'enregistrer') {
            param_set($pdo, 'volume', (string)max(0, min(100, (int)($_POST['volume'] ?? 30))));
            $vides = [];
            foreach (SONS as $type => [$nom]) {
                $motif = normaliser_motif((string)($_POST['motif'][$type] ?? ''));
                if ($motif === '') { $vides[] = $nom; continue; }
                param_set($pdo, 'motif_' . $type, $motif);
            }
            flash('succes', 'Sons enregistrés. Les lecteurs les appliquent dans les 3 secondes.');
            if ($vides) flash('erreur', 'Son non modifié (aucune note valide) : ' . implode(', ', $vides) . '. Format attendu : 1500:200 0:100 2000:300');
        } elseif ($action === 'reinitialiser') {
            $type = (string)($_POST['type'] ?? '');
            if (isset(SONS[$type])) {
                param_set($pdo, 'motif_' . $type, SONS[$type][2]);
                flash('succes', 'Son « ' . SONS[$type][0] . ' » remis par défaut.');
            }
        } elseif ($action === 'alerte' || $action === 'alerte_stop') {
            $ids = ($_POST['id'] ?? '') === 'tous'
                ? $pdo->query('SELECT id FROM lecteurs')->fetchAll(PDO::FETCH_COLUMN)
                : [(int)($_POST['id'] ?? 0)];
            foreach ($ids as $lid) param_set($pdo, 'alerte_' . (int)$lid, $action === 'alerte' ? (string)time() : '');
            flash($action === 'alerte' ? 'erreur' : 'succes', $action === 'alerte'
                ? '☢ Alerte déclenchée. La sirène démarre dans les 3 secondes (arrêt automatique au bout de 5 minutes).'
                : 'Alerte levée. Retour au calme.');
            redirect('parametres.php#protocole');
        } elseif ($action === 'tester') {
            $id = (int)($_POST['id'] ?? 0);
            $type = isset(SONS[$_POST['type'] ?? '']) ? $_POST['type'] : 'valide';
            param_set($pdo, 'test_' . $id, $type . '|' . time());
            flash('succes', 'Test envoyé : le lecteur va jouer « ' . SONS[$type][0] . ' » dans les 3 secondes s\'il est allumé.');
        }
    } catch (PDOException $ex) {
        flash('erreur', 'Erreur de base de données : ' . $ex->getMessage());
    }
    redirect('parametres.php');
}

$volume = (int)param_get($pdo, 'volume');
$motifs = [];
foreach (array_keys(SONS) as $type) $motifs[$type] = motif_son($pdo, $type);
$lecteurs = $pdo->query('SELECT id, nom, emplacement FROM lecteurs ORDER BY id')->fetchAll();
foreach ($lecteurs as &$l) {
    $vu = (int)param_get($pdo, 'vu_' . $l['id'], '0');
    $l['vu'] = $vu;
    $l['en_ligne'] = $vu && time() - $vu <= 15;
    $a = (int)param_get($pdo, 'alerte_' . $l['id'], '0');
    $l['alerte'] = $a && time() - $a <= 300;
}
unset($l);

$title = 'Paramètres';
$page = 'parametres';
require __DIR__ . '/includes/header.php';
?>
<form method="post" id="form-son">
  <?= csrf_field() ?>
  <input type="hidden" name="action" value="enregistrer">

  <section class="panneau">
    <div class="panneau-tete"><h2>Volume</h2><span class="muted">Commun à tous les sons et tous les lecteurs</span></div>
    <label>Volume : <output id="vol-aff" class="mono"><?= $volume ?><?= $volume === 0 ? ' (muet)' : '' ?></output>
      <input type="range" name="volume" id="volume" min="0" max="100" step="5" value="<?= $volume ?>" oninput="document.getElementById('vol-aff').textContent = this.value + (this.value == 0 ? ' (muet)' : '')">
    </label>
    <p class="muted">Repères : 0 = muet, 10 = discret, 30 = moyen, 100 = maximum.</p>
  </section>

  <section class="panneau">
    <div class="panneau-tete"><h2>Sons</h2><span class="muted">Une note = fréquence:durée (Hz:ms), 0 = silence</span></div>
    <p class="muted">Exemple : <code>1000:120 1500:120 2000:250</code> joue trois notes qui montent. Grave vers 200–400 Hz, aigu vers 1 500–2 500 Hz (le buzzer sonne le plus fort entre 2 000 et 3 000 Hz). 16 notes et 6 secondes maximum par son.</p>
    <div class="sons">
      <?php foreach (SONS as $type => [$nom, $aide]): ?>
        <div class="son-bloc">
          <div class="son-tete">
            <h3><?= e($nom) ?></h3>
            <span class="muted"><?= e($aide) ?></span>
          </div>
          <input class="mono" name="motif[<?= $type ?>]" id="motif-<?= $type ?>" value="<?= e($motifs[$type]) ?>" aria-label="Notes du son <?= e($nom) ?>" required>
          <div class="actions">
            <button type="button" class="btn btn-sm" onclick="apercu('<?= $type ?>')">Écouter ici</button>
            <select aria-label="Modèle pour <?= e($nom) ?>" onchange="if (this.value) { document.getElementById('motif-<?= $type ?>').value = this.value; apercu('<?= $type ?>'); } this.selectedIndex = 0;">
              <option value="">Choisir un modèle…</option>
              <?php foreach (SONS_MODELES as $lib => $m): ?><option value="<?= e($m) ?>"><?= e($lib) ?></option><?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm" form="reinit-<?= $type ?>">Son par défaut</button>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
    <div class="actions mt"><button class="btn btn-primaire">Enregistrer les sons</button></div>
  </section>
</form>

<?php foreach (array_keys(SONS) as $type): ?>
  <form method="post" id="reinit-<?= $type ?>" hidden<?= confirm_attr('Remettre le son « ' . SONS[$type][0] . ' » par défaut ?') ?>><?= csrf_field() ?><input type="hidden" name="action" value="reinitialiser"><input type="hidden" name="type" value="<?= $type ?>"></form>
<?php endforeach; ?>

<section class="panneau">
  <div class="panneau-tete"><h2>Tester sur un lecteur</h2><span class="muted">Le lecteur joue le son enregistré, avec sa LED</span></div>
  <?php if (!$lecteurs): ?>
    <p class="vide">Aucun lecteur. <a href="lecteurs.php">Créez-en un</a>.</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>N°</th><th>Lecteur</th><th>Connexion</th><th>Faire sonner</th></tr></thead>
    <tbody>
    <?php foreach ($lecteurs as $l): ?>
      <tr>
        <td class="mono"><?= (int)$l['id'] ?></td>
        <td><?= e($l['nom']) ?><?= $l['emplacement'] ? '<br><span class="muted">' . e($l['emplacement']) . '</span>' : '' ?></td>
        <td><?= $l['en_ligne'] ? '<span class="tag ok">En ligne</span>' : '<span class="tag neutre">Hors ligne</span>' . ($l['vu'] ? '<br><span class="muted mono">vu le ' . e(date('d/m H:i', $l['vu'])) . '</span>' : '') ?></td>
        <td>
          <form method="post" class="inline ligne-stock">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="tester">
            <input type="hidden" name="id" value="<?= (int)$l['id'] ?>">
            <select name="type" aria-label="Son à tester sur <?= e($l['nom']) ?>">
              <?php foreach (SONS as $type => [$nom]): ?><option value="<?= $type ?>"><?= e($nom) ?></option><?php endforeach; ?>
            </select>
            <button class="btn btn-sm">Tester</button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <p class="muted">Enregistrez d'abord vos modifications : le lecteur joue le son enregistré. « En ligne » : contact avec le serveur il y a moins de 15 secondes.</p>
  <?php endif; ?>
</section>

<section class="panneau panneau-alerte" id="protocole" hidden>
  <div class="panneau-tete"><h2>☢ Protocole d'alerte</h2><span class="muted">Classifié. Sirène sur le buzzer uniquement.</span></div>
  <p class="muted">La sirène tourne sur le lecteur jusqu'à ce que vous cliquiez sur Stop (ou 5 minutes maximum). Pendant l'alerte, le lecteur ignore les badges.</p>
  <?php if (!$lecteurs): ?>
    <p class="vide">Aucun lecteur à faire hurler.</p>
  <?php else: ?>
  <div class="table-wrap"><table>
    <thead><tr><th>Lecteur</th><th>État</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($lecteurs as $l): ?>
      <tr>
        <td><?= e($l['nom']) ?></td>
        <td><?= $l['alerte'] ? '<span class="tag ko clignote">Sirène active</span>' : '<span class="tag neutre">Calme</span>' ?></td>
        <td class="actions">
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="alerte"><input type="hidden" name="id" value="<?= (int)$l['id'] ?>"><button class="btn btn-sm btn-danger">Déclencher</button></form>
          <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="alerte_stop"><input type="hidden" name="id" value="<?= (int)$l['id'] ?>"><button class="btn btn-sm">Stop</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <div class="actions mt">
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="alerte"><input type="hidden" name="id" value="tous"><button class="btn btn-danger">☢ Alerte générale</button></form>
    <form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="action" value="alerte_stop"><input type="hidden" name="id" value="tous"><button class="btn btn-primaire">Stop partout</button></form>
  </div>
  <?php endif; ?>
</section>

<script>
// Easter egg : 5 clics rapides sur le titre « Paramètres » révèlent le protocole d'alerte
(function () {
  var zone = document.getElementById('protocole'), titre = document.querySelector('.topbar h1');
  if (!zone || !titre) return;
  if (location.hash === '#protocole') zone.hidden = false;
  var clics = 0, minuteur;
  titre.style.userSelect = 'none';
  titre.addEventListener('click', function () {
    clics++;
    clearTimeout(minuteur);
    minuteur = setTimeout(function () { clics = 0; }, 1500);
    if (clics >= 5) { clics = 0; zone.hidden = !zone.hidden; if (!zone.hidden) zone.scrollIntoView({ behavior: 'smooth' }); }
  });
})();
</script>

<script>
// Aperçu dans le navigateur (son carré, comme le buzzer)
function apercu(type) {
  var AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  var notes = [], re = /(\d+)\s*:\s*(\d+)/g, m;
  while ((m = re.exec(document.getElementById('motif-' + type).value)) && notes.length < 16) notes.push([Number(m[1]), Math.min(3000, Number(m[2]))]);
  if (!notes.length) return;
  var ctx = new AC(), osc = ctx.createOscillator(), gain = ctx.createGain();
  var vol = Number(document.getElementById('volume').value) / 100, t = ctx.currentTime;
  osc.type = 'square';
  osc.connect(gain); gain.connect(ctx.destination);
  notes.forEach(function (n) {
    if (n[0] > 0) { osc.frequency.setValueAtTime(n[0], t); gain.gain.setValueAtTime(0.25 * vol * vol, t); }
    else gain.gain.setValueAtTime(0, t);
    t += n[1] / 1000;
  });
  gain.gain.setValueAtTime(0, t);
  osc.start(); osc.stop(t + 0.05);
  osc.onended = function () { ctx.close(); };
}
</script>
<?php require __DIR__ . '/includes/footer.php';
