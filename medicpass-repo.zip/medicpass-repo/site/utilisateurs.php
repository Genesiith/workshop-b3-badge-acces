<?php
// Ancienne page (v1) : remplacée par patients.php
header('Location: patients.php');
