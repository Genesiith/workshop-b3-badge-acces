<?php
// Ancienne page (v1) : remplacée par patient.php
header('Location: patient.php?id=' . (int)($_GET['id'] ?? 0));
