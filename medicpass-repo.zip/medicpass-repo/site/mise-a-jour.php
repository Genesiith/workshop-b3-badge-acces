<?php
// Passe une installation de la version 1 (crédits) à la version 2 (ordonnances + rôles)
require __DIR__ . '/includes/init.php';
require __DIR__ . '/includes/page_simple.php';
require __DIR__ . '/includes/comptes_defaut.php';
check_csrf();

$etat = '';
$message = '';
try {
    $pdo = db();
    // Base déjà en v2 ou plus : seul un administrateur connecté peut lancer la mise à jour
    $roleExiste = (bool)$pdo->query("SHOW COLUMNS FROM admins LIKE 'role'")->fetch();
    if ($roleExiste && role() !== 'admin') {
        $etat = 'deja';
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $schema = require __DIR__ . '/includes/schema.php';
        $pdo->exec("ALTER TABLE admins ADD COLUMN IF NOT EXISTS role ENUM('admin','medecin','pharmacien') NOT NULL DEFAULT 'admin'");
        $pdo->exec("ALTER TABLE lecteurs MODIFY type ENUM('acces','distributeur','pharmacie') NOT NULL DEFAULT 'acces'");
        $pdo->exec("UPDATE lecteurs SET type = 'pharmacie' WHERE type = 'distributeur'");
        $pdo->exec("ALTER TABLE lecteurs MODIFY type ENUM('acces','pharmacie') NOT NULL DEFAULT 'acces'");
        foreach (['ordonnances', 'ordonnance_lignes', 'delivrances', 'borne_sessions', 'conditions', 'patient_conditions', 'medicament_contre_indications'] as $t) {
            $pdo->exec($schema[$t]);
        }
        $pdo->exec('ALTER TABLE medicaments ADD COLUMN IF NOT EXISTS delai_minutes INT NOT NULL DEFAULT 0');
        $cree = !$roleExiste && creer_compte_medecin($pdo);
        $etat = 'fait';
        $message = $cree ? 'Compte « Medecin » créé.' : '';
    }
} catch (PDOException $ex) {
    $etat = 'erreur';
    $message = $ex->getMessage();
}

page_simple_debut('Mise à jour v3');
if ($etat === 'erreur'): ?>
    <div class="alerte alerte-erreur">Erreur : <?= e($message) ?></div>
<?php elseif ($etat === 'deja'): ?>
    <div class="alerte alerte-info">Connectez-vous avec un compte administrateur, puis rouvrez cette page.</div>
    <p><a href="login.php">Se connecter</a></p>
<?php elseif ($etat === 'fait'): ?>
    <div class="alerte alerte-succes">Base mise à jour : ordonnances, écran pharmacie, rôles, délais entre prises et conditions médicales activés. <?= e($message) ?></div>
    <p><strong>Supprimez maintenant <code>mise-a-jour.php</code></strong> du serveur, puis <a href="logout.php">reconnectez-vous</a>.</p>
<?php else: ?>
    <p>Cette page ajoute les ordonnances, l'écran pharmacie, les profils (administrateur, médecin, pharmacien), les délais entre deux prises et les conditions médicales (contre-indications). Vos patients, lecteurs, médicaments et votre journal sont conservés. Les distributeurs deviennent des bornes pharmacie.</p>
    <form method="post" class="formulaire">
      <?= csrf_field() ?>
      <button class="btn btn-primaire btn-large">Lancer la mise à jour</button>
    </form>
<?php endif;
page_simple_fin();
