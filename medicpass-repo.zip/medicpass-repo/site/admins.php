<?php
// Ancienne page (v1) : remplacée par comptes.php
header('Location: comptes.php');
