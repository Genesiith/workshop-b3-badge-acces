<?php
require __DIR__ . '/includes/init.php';
require_role('admin');
$pdo = db();

$stats = [
    'Passages aujourd\'hui' => $pdo->query("SELECT COUNT(*) FROM logs WHERE date_heure >= CURDATE()")->fetchColumn(),
    'Refus aujourd\'hui' => $pdo->query("SELECT COUNT(*) FROM logs WHERE date_heure >= CURDATE() AND resultat = 'refuse'")->fetchColumn(),
    'Produits délivrés aujourd\'hui' => $pdo->query("SELECT COALESCE(SUM(quantite), 0) FROM delivrances WHERE date_heure >= CURDATE()")->fetchColumn(),
    'Ordonnances actives' => $pdo->query("SELECT COUNT(*) FROM ordonnances WHERE statut = 'active' AND date_expiration >= CURDATE()")->fetchColumn(),
];
$stockBas = $pdo->prepare("SELECT id, nom, stock FROM medicaments WHERE actif = 1 AND stock <= ? ORDER BY stock");
$stockBas->execute([STOCK_ALERTE]);
$stockBas = $stockBas->fetchAll();
$derniers = $pdo->query(LOGS_SELECT . " ORDER BY l.id DESC LIMIT 10")->fetchAll();
$lecteurs = $pdo->query("SELECT id, nom, emplacement, type, actif, derniere_activite FROM lecteurs ORDER BY nom")->fetchAll();

$title = 'Tableau de bord';
$page = 'index';
require __DIR__ . '/includes/header.php';
?>
<div class="stats">
  <?php foreach ($stats as $label => $val): ?>
    <div class="stat"><span class="stat-label"><?= e($label) ?></span><span class="stat-val"><?= (int)$val ?></span></div>
  <?php endforeach; ?>
</div>

<?php if ($stockBas): ?>
  <div class="alerte alerte-attention">
    Stock bas :
    <?php foreach ($stockBas as $i => $m): ?>
      <?= $i ? ', ' : '' ?><a href="medicaments.php?edit=<?= (int)$m['id'] ?>"><?= e($m['nom']) ?></a> (<?= (int)$m['stock'] ?>)
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<section class="panneau">
  <div class="panneau-tete"><h2>Dernières lectures</h2><a href="logs.php">Journal complet</a></div>
  <?= logs_table($derniers) ?>
</section>

<section class="panneau">
  <div class="panneau-tete"><h2>Lecteurs</h2><a href="lecteurs.php">Gérer les lecteurs</a></div>
  <?php if (!$lecteurs): ?>
    <p class="vide">Aucun lecteur. <a href="lecteurs.php">Ajoutez votre premier lecteur</a> pour obtenir sa clé à mettre dans la carte.</p>
  <?php else: ?>
    <div class="table-wrap"><table>
      <thead><tr><th>Nom</th><th>Dernier badge lu</th><th>Statut</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($lecteurs as $l): ?>
        <tr>
          <td><?= e($l['nom']) ?><?= $l['emplacement'] ? '<br><span class="muted">' . e($l['emplacement']) . '</span>' : '' ?></td>
          <td class="mono"><?= e(date_fr($l['derniere_activite'], true, false)) ?></td>
          <td><?= $l['actif'] ? '<span class="tag ok">En ligne</span>' : '<span class="tag neutre">Désactivé</span>' ?></td>
          <td><a class="btn btn-sm" href="borne.php?lecteur=<?= (int)$l['id'] ?>">Ouvrir l'écran</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php';
