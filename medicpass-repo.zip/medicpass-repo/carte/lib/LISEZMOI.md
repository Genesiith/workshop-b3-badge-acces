Bibliothèque du lecteur PN532 à ajouter ici (non incluse dans le dépôt) :
télécharger https://github.com/elechouse/PN532 (bouton Code > Download ZIP)
et copier les dossiers PN532 et PN532_I2C dans ce dossier lib/.
