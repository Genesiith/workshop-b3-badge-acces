# Medic Pass

Délivrance de médicaments sur ordonnance par badge RFID — Workshop IoT EPSI (B3).

Le médecin prescrit une ordonnance sur le site. Le patient passe son badge sur le lecteur de la pharmacie :
l'écran en face de lui affiche les médicaments auxquels il a droit, il choisit ce qu'il retire, et tout est
enregistré (stock, ordonnance, journal, statistiques). Le lecteur répond par une LED (verte / rouge) et un son.

## Contenu du dépôt

| Dossier | Contenu | Technologie |
|---|---|---|
| `carte/` | Programme du lecteur (carte NodeMCU + module RFID PN532, LED, buzzer) | C++ (framework Arduino) sur ESP8266, PlatformIO |
| `site/` | Site web : administration, espace médecin, écran pharmacie, API des lecteurs | PHP 8, MariaDB/MySQL, JavaScript |

## Fonctionnement

1. La carte lit le badge (PN532 en I2C) et envoie son numéro en Wi-Fi à `site/api/badge.php`.
2. Le PHP vérifie le patient, ses ordonnances actives, les délais entre deux prises et les contre-indications
   (conditions médicales du patient), puis répond `autorisé` ou `refusé` et écrit une ligne dans le journal.
3. L'écran pharmacie (`borne.php`) affiche l'ordonnance du patient ; la délivrance met à jour le stock et l'ordonnance.
4. La carte lit ses réglages (volume, sons) toutes les 3 secondes via `site/api/reglages.php`.

Profils du site : **administrateur** (tout), **médecin** (ordonnances), **pharmacien** (écran pharmacie).

## Matériel et câblage

| PN532 | NodeMCU |
|---|---|
| VCC | 3V |
| GND | G |
| SDA | D2 |
| SCL | D1 |

Interrupteur du PN532 : **1 sur ON, 2 pas sur ON** (mode I2C), poussés à fond.

| Composant | Broche |
|---|---|
| LED verte (+ résistance) | D5 |
| LED rouge (+ résistance) | D8 |
| Buzzer : S / milieu / − | D7 / 3V / G |

## Installation du site

1. Hébergement PHP 8 + MariaDB (ex. Pterodactyl avec l'egg Nginx de Ym0T).
2. Copier le contenu de `site/` à la racine web.
3. Copier `config.exemple.php` en `config.php` et renseigner la base de données.
4. Ouvrir `install.php`, créer le compte administrateur, puis supprimer `install.php` et `mise-a-jour.php`.
   (Base existante d'une version précédente : utiliser `mise-a-jour.php` connecté en administrateur.)

## Installation de la carte

1. Ouvrir `carte/` dans CLion avec le plugin PlatformIO.
2. Ajouter la bibliothèque PN532 dans `carte/lib/` (voir `carte/lib/LISEZMOI.md`).
3. Dans `carte/src/main.cpp`, renseigner le Wi-Fi (2,4 GHz), l'adresse du site, le numéro et la clé du lecteur
   (page **Lecteurs** du site).
4. Upload and Monitor.

## Sécurité

- `site/config.php` (mots de passe de la base) n'est jamais publié.
- Dans le dépôt, `carte/src/main.cpp` contient des valeurs d'exemple : ne pas y committer le vrai mot de passe
  Wi-Fi ni la vraie clé du lecteur.
